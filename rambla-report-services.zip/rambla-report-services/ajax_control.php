<?php
require_once("include/dbcommon.php"); // DataBase PHPRunner
/*
if (!isset($_POST['valor'])) { //  Control of the call and verification of the existence of the parameter
  echo("0;;Please provide a Valor.");
  die();
}
$valor = $_POST['valor'];
*/
sleep(5); //  Sleep for 5 seconds

echo "1;'';Bye Bye";
?>