<?php
$html = <<<EOT
<style>
.overlay{
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(255,255,255,0.8) url("calculated.gif") center no-repeat;

}
/* Turn off scrollbar when body element has the loading class */
body.loading{
    overflow: hidden;   
}
/* Make spinner image visible when body element has the loading class */
body.loading .overlay{
    display: block;
}
</style>
Aquí el GIF  /* Este texto hay que quitarlo | This text must be removed */
<div class="overlay"></div>

</script>

EOT;

echo $html;