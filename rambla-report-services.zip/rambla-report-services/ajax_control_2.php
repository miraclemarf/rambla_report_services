<?php
require_once("include/dbcommon.php"); // DataBase PHPRunner

while (true)  { // Control to wait for the ADD operation has finished
 if (isset($_SESSION['SaveTable2'])) { // 
			break;	
	} else {
			session_write_close();   // Close SESSION
			sleep(1); 								//  Sleep for 1 seconds
			session_start();					// Open SESSION
	}
}


sleep(5); // Test

unset($_SESSION['SaveTable2']); // Delete SESSION

echo "1;'';Bye Bye";
?>