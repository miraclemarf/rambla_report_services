<?php
$tdatadepartment_brand3 = array();
$tdatadepartment_brand3[".searchableFields"] = array();
$tdatadepartment_brand3[".ShortName"] = "department_brand3";
$tdatadepartment_brand3[".OwnerID"] = "";
$tdatadepartment_brand3[".OriginalTable"] = "ecommerce_detailsku2";


$tdatadepartment_brand3[".pagesByType"] = my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" );
$tdatadepartment_brand3[".originalPagesByType"] = $tdatadepartment_brand3[".pagesByType"];
$tdatadepartment_brand3[".pages"] = types2pages( my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" ) );
$tdatadepartment_brand3[".originalPages"] = $tdatadepartment_brand3[".pages"];
$tdatadepartment_brand3[".defaultPages"] = my_json_decode( "{\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\"}" );
$tdatadepartment_brand3[".originalDefaultPages"] = $tdatadepartment_brand3[".defaultPages"];

//	field labels
$fieldLabelsdepartment_brand3 = array();
$fieldToolTipsdepartment_brand3 = array();
$pageTitlesdepartment_brand3 = array();
$placeHoldersdepartment_brand3 = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdepartment_brand3["English"] = array();
	$fieldToolTipsdepartment_brand3["English"] = array();
	$placeHoldersdepartment_brand3["English"] = array();
	$pageTitlesdepartment_brand3["English"] = array();
	$fieldLabelsdepartment_brand3["English"]["DEPT"] = "Dept";
	$fieldToolTipsdepartment_brand3["English"]["DEPT"] = "";
	$placeHoldersdepartment_brand3["English"]["DEPT"] = "";
	$fieldLabelsdepartment_brand3["English"]["brand_code"] = "Brand Code";
	$fieldToolTipsdepartment_brand3["English"]["brand_code"] = "";
	$placeHoldersdepartment_brand3["English"]["brand_code"] = "";
	if (count($fieldToolTipsdepartment_brand3["English"]))
		$tdatadepartment_brand3[".isUseToolTips"] = true;
}


	$tdatadepartment_brand3[".NCSearch"] = true;



$tdatadepartment_brand3[".shortTableName"] = "department_brand3";
$tdatadepartment_brand3[".nSecOptions"] = 0;

$tdatadepartment_brand3[".mainTableOwnerID"] = "";
$tdatadepartment_brand3[".entityType"] = 1;
$tdatadepartment_brand3[".connId"] = "dbcentral_at_192_168_8_99";


$tdatadepartment_brand3[".strOriginalTableName"] = "ecommerce_detailsku2";

	



$tdatadepartment_brand3[".showAddInPopup"] = false;

$tdatadepartment_brand3[".showEditInPopup"] = false;

$tdatadepartment_brand3[".showViewInPopup"] = false;

$tdatadepartment_brand3[".listAjax"] = false;
//	temporary
//$tdatadepartment_brand3[".listAjax"] = false;

	$tdatadepartment_brand3[".audit"] = false;

	$tdatadepartment_brand3[".locking"] = false;


$pages = $tdatadepartment_brand3[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadepartment_brand3[".edit"] = true;
	$tdatadepartment_brand3[".afterEditAction"] = 1;
	$tdatadepartment_brand3[".closePopupAfterEdit"] = 1;
	$tdatadepartment_brand3[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadepartment_brand3[".add"] = true;
$tdatadepartment_brand3[".afterAddAction"] = 1;
$tdatadepartment_brand3[".closePopupAfterAdd"] = 1;
$tdatadepartment_brand3[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadepartment_brand3[".list"] = true;
}



$tdatadepartment_brand3[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadepartment_brand3[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadepartment_brand3[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadepartment_brand3[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadepartment_brand3[".printFriendly"] = true;
}



$tdatadepartment_brand3[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadepartment_brand3[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadepartment_brand3[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadepartment_brand3[".isUseAjaxSuggest"] = true;





$tdatadepartment_brand3[".ajaxCodeSnippetAdded"] = false;

$tdatadepartment_brand3[".buttonsAdded"] = false;

$tdatadepartment_brand3[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadepartment_brand3[".isUseTimeForSearch"] = false;


$tdatadepartment_brand3[".badgeColor"] = "CD853F";


$tdatadepartment_brand3[".allSearchFields"] = array();
$tdatadepartment_brand3[".filterFields"] = array();
$tdatadepartment_brand3[".requiredSearchFields"] = array();

$tdatadepartment_brand3[".googleLikeFields"] = array();
$tdatadepartment_brand3[".googleLikeFields"][] = "DEPT";
$tdatadepartment_brand3[".googleLikeFields"][] = "brand_code";



$tdatadepartment_brand3[".tableType"] = "list";

$tdatadepartment_brand3[".printerPageOrientation"] = 0;
$tdatadepartment_brand3[".nPrinterPageScale"] = 100;

$tdatadepartment_brand3[".nPrinterSplitRecords"] = 40;

$tdatadepartment_brand3[".geocodingEnabled"] = false;










$tdatadepartment_brand3[".pageSize"] = 20;

$tdatadepartment_brand3[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdatadepartment_brand3[".strOrderBy"] = $tstrOrderBy;

$tdatadepartment_brand3[".orderindexes"] = array();


$tdatadepartment_brand3[".sqlHead"] = "select distinct DEPT,  brand_code";
$tdatadepartment_brand3[".sqlFrom"] = "FROM r_sales";
$tdatadepartment_brand3[".sqlWhereExpr"] = "(brand_code in (select brand from v_user_login_brand where username  = 'user:username'))";
$tdatadepartment_brand3[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadepartment_brand3[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadepartment_brand3[".arrGroupsPerPage"] = $arrGPP;

$tdatadepartment_brand3[".highlightSearchResults"] = true;

$tableKeysdepartment_brand3 = array();
$tdatadepartment_brand3[".Keys"] = $tableKeysdepartment_brand3;


$tdatadepartment_brand3[".hideMobileList"] = array();




//	DEPT
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "DEPT";
	$fdata["GoodName"] = "DEPT";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("department_brand3","DEPT");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DEPT";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DEPT";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadepartment_brand3["DEPT"] = $fdata;
		$tdatadepartment_brand3[".searchableFields"][] = "DEPT";
//	brand_code
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "brand_code";
	$fdata["GoodName"] = "brand_code";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("department_brand3","brand_code");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_code";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "brand_code";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadepartment_brand3["brand_code"] = $fdata;
		$tdatadepartment_brand3[".searchableFields"][] = "brand_code";


$tables_data["department_brand3"]=&$tdatadepartment_brand3;
$field_labels["department_brand3"] = &$fieldLabelsdepartment_brand3;
$fieldToolTips["department_brand3"] = &$fieldToolTipsdepartment_brand3;
$placeHolders["department_brand3"] = &$placeHoldersdepartment_brand3;
$page_titles["department_brand3"] = &$pageTitlesdepartment_brand3;


changeTextControlsToDate( "department_brand3" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["department_brand3"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["department_brand3"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_department_brand3()
{
$proto0=array();
$proto0["m_strHead"] = "select distinct";
$proto0["m_strFieldList"] = "DEPT,  brand_code";
$proto0["m_strFrom"] = "FROM r_sales";
$proto0["m_strWhere"] = "(brand_code in (select brand from v_user_login_brand where username  = 'user:username'))";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "brand_code in (select brand from v_user_login_brand where username  = 'user:username')";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "department_brand3"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "in (select brand from v_user_login_brand where username  = 'user:username')";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "DEPT",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "department_brand3"
));

$proto6["m_sql"] = "DEPT";
$proto6["m_srcTableName"] = "department_brand3";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "department_brand3"
));

$proto8["m_sql"] = "brand_code";
$proto8["m_srcTableName"] = "department_brand3";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto10=array();
$proto10["m_link"] = "SQLL_MAIN";
			$proto11=array();
$proto11["m_strName"] = "r_sales";
$proto11["m_srcTableName"] = "department_brand3";
$proto11["m_columns"] = array();
$proto11["m_columns"][] = "id";
$proto11["m_columns"][] = "periode";
$proto11["m_columns"][] = "DIVISION";
$proto11["m_columns"][] = "SUB_DIVISION";
$proto11["m_columns"][] = "category_code";
$proto11["m_columns"][] = "DEPT";
$proto11["m_columns"][] = "SUB_DEPT";
$proto11["m_columns"][] = "brand_code";
$proto11["m_columns"][] = "brand_name";
$proto11["m_columns"][] = "barcode";
$proto11["m_columns"][] = "article_name";
$proto11["m_columns"][] = "varian_option1";
$proto11["m_columns"][] = "varian_option2";
$proto11["m_columns"][] = "price";
$proto11["m_columns"][] = "vendor_code";
$proto11["m_columns"][] = "margin";
$proto11["m_columns"][] = "tot_qty";
$proto11["m_columns"][] = "disc_pct";
$proto11["m_columns"][] = "total_disc_amt";
$proto11["m_columns"][] = "moredisc_pct";
$proto11["m_columns"][] = "total_moredisc_amt";
$proto11["m_columns"][] = "gross";
$proto11["m_columns"][] = "net";
$proto11["m_columns"][] = "gross_after_margin";
$proto11["m_columns"][] = "source_dat";
$proto11["m_columns"][] = "tag_5";
$proto11["m_columns"][] = "vendor_type";
$proto11["m_columns"][] = "fee";
$obj = new SQLTable($proto11);

$proto10["m_table"] = $obj;
$proto10["m_sql"] = "r_sales";
$proto10["m_alias"] = "";
$proto10["m_srcTableName"] = "department_brand3";
$proto12=array();
$proto12["m_sql"] = "";
$proto12["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto12["m_column"]=$obj;
$proto12["m_contained"] = array();
$proto12["m_strCase"] = "";
$proto12["m_havingmode"] = false;
$proto12["m_inBrackets"] = false;
$proto12["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto12);

$proto10["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto10);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="department_brand3";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_department_brand3 = createSqlQuery_department_brand3();


	
		;

		

$tdatadepartment_brand3[".sqlquery"] = $queryData_department_brand3;



$tdatadepartment_brand3[".hasEvents"] = false;

?>