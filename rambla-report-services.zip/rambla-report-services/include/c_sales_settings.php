<?php
$tdatac_sales = array();
$tdatac_sales[".searchableFields"] = array();
$tdatac_sales[".ShortName"] = "c_sales";
$tdatac_sales[".OwnerID"] = "";
$tdatac_sales[".OriginalTable"] = "artikel_pwp";


$tdatac_sales[".pagesByType"] = my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" );
$tdatac_sales[".originalPagesByType"] = $tdatac_sales[".pagesByType"];
$tdatac_sales[".pages"] = types2pages( my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" ) );
$tdatac_sales[".originalPages"] = $tdatac_sales[".pages"];
$tdatac_sales[".defaultPages"] = my_json_decode( "{\"chart\":\"chart\",\"search\":\"search\"}" );
$tdatac_sales[".originalDefaultPages"] = $tdatac_sales[".defaultPages"];

//	field labels
$fieldLabelsc_sales = array();
$fieldToolTipsc_sales = array();
$pageTitlesc_sales = array();
$placeHoldersc_sales = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsc_sales["English"] = array();
	$fieldToolTipsc_sales["English"] = array();
	$placeHoldersc_sales["English"] = array();
	$pageTitlesc_sales["English"] = array();
	$fieldLabelsc_sales["English"]["source_dat"] = "Source Dat";
	$fieldToolTipsc_sales["English"]["source_dat"] = "";
	$placeHoldersc_sales["English"]["source_dat"] = "";
	$fieldLabelsc_sales["English"]["tot_qty"] = "Tot Qty";
	$fieldToolTipsc_sales["English"]["tot_qty"] = "";
	$placeHoldersc_sales["English"]["tot_qty"] = "";
	$fieldLabelsc_sales["English"]["net"] = "Net";
	$fieldToolTipsc_sales["English"]["net"] = "";
	$placeHoldersc_sales["English"]["net"] = "";
	if (count($fieldToolTipsc_sales["English"]))
		$tdatac_sales[".isUseToolTips"] = true;
}


	$tdatac_sales[".NCSearch"] = true;

	$tdatac_sales[".ChartRefreshTime"] = 0;


$tdatac_sales[".shortTableName"] = "c_sales";
$tdatac_sales[".nSecOptions"] = 0;

$tdatac_sales[".mainTableOwnerID"] = "";
$tdatac_sales[".entityType"] = 3;
$tdatac_sales[".connId"] = "dbcentral_at_192_168_8_99";


$tdatac_sales[".strOriginalTableName"] = "artikel_pwp";

	



$tdatac_sales[".showAddInPopup"] = false;

$tdatac_sales[".showEditInPopup"] = false;

$tdatac_sales[".showViewInPopup"] = false;

$tdatac_sales[".listAjax"] = false;
//	temporary
//$tdatac_sales[".listAjax"] = false;

	$tdatac_sales[".audit"] = false;

	$tdatac_sales[".locking"] = false;


$pages = $tdatac_sales[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatac_sales[".edit"] = true;
	$tdatac_sales[".afterEditAction"] = 1;
	$tdatac_sales[".closePopupAfterEdit"] = 1;
	$tdatac_sales[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatac_sales[".add"] = true;
$tdatac_sales[".afterAddAction"] = 1;
$tdatac_sales[".closePopupAfterAdd"] = 1;
$tdatac_sales[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatac_sales[".list"] = true;
}



$tdatac_sales[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatac_sales[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatac_sales[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatac_sales[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatac_sales[".printFriendly"] = true;
}



$tdatac_sales[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatac_sales[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatac_sales[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatac_sales[".isUseAjaxSuggest"] = true;





$tdatac_sales[".ajaxCodeSnippetAdded"] = false;

$tdatac_sales[".buttonsAdded"] = false;

$tdatac_sales[".addPageEvents"] = false;

// use timepicker for search panel
$tdatac_sales[".isUseTimeForSearch"] = false;


$tdatac_sales[".badgeColor"] = "D2691E";


$tdatac_sales[".allSearchFields"] = array();
$tdatac_sales[".filterFields"] = array();
$tdatac_sales[".requiredSearchFields"] = array();

$tdatac_sales[".googleLikeFields"] = array();
$tdatac_sales[".googleLikeFields"][] = "source_dat";
$tdatac_sales[".googleLikeFields"][] = "tot_qty";
$tdatac_sales[".googleLikeFields"][] = "net";



$tdatac_sales[".tableType"] = "chart";

$tdatac_sales[".printerPageOrientation"] = 0;
$tdatac_sales[".nPrinterPageScale"] = 100;

$tdatac_sales[".nPrinterSplitRecords"] = 40;

$tdatac_sales[".geocodingEnabled"] = false;



// chart settings
$tdatac_sales[".chartType"] = "2DPie";
// end of chart settings








$tstrOrderBy = "";
$tdatac_sales[".strOrderBy"] = $tstrOrderBy;

$tdatac_sales[".orderindexes"] = array();


$tdatac_sales[".sqlHead"] = "select source_dat,  SUM(tot_qty) AS tot_qty,  SUM(net) AS net";
$tdatac_sales[".sqlFrom"] = "FROM r_sales";
$tdatac_sales[".sqlWhereExpr"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      ))";
$tdatac_sales[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatac_sales[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatac_sales[".arrGroupsPerPage"] = $arrGPP;

$tdatac_sales[".highlightSearchResults"] = true;

$tableKeysc_sales = array();
$tdatac_sales[".Keys"] = $tableKeysc_sales;


$tdatac_sales[".hideMobileList"] = array();




//	source_dat
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "source_dat";
	$fdata["GoodName"] = "source_dat";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("c_sales","source_dat");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "source_dat";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "source_dat";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales["source_dat"] = $fdata;
		$tdatac_sales[".searchableFields"][] = "source_dat";
//	tot_qty
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "tot_qty";
	$fdata["GoodName"] = "tot_qty";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("c_sales","tot_qty");
	$fdata["FieldType"] = 14;


	
	
			

		$fdata["strField"] = "tot_qty";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "SUM(tot_qty)";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales["tot_qty"] = $fdata;
		$tdatac_sales[".searchableFields"][] = "tot_qty";
//	net
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "net";
	$fdata["GoodName"] = "net";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("c_sales","net");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "net";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "SUM(net)";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales["net"] = $fdata;
		$tdatac_sales[".searchableFields"][] = "net";

$tdatac_sales[".chartLabelField"] = "source_dat";
$tdatac_sales[".chartSeries"] = array();
$tdatac_sales[".chartSeries"][] = array(
	"field" => "net",
	"total" => ""
);
	$tdatac_sales[".chartXml"] = '<chart>
		<attr value="tables">
			<attr value="0">c_sales</attr>
		</attr>
		<attr value="chart_type">
			<attr value="type">2d_pie</attr>
		</attr>

		<attr value="parameters">';
	$tdatac_sales[".chartXml"] .= '<attr value="0">
			<attr value="name">net</attr>';
	$tdatac_sales[".chartXml"] .= '</attr>';
	$tdatac_sales[".chartXml"] .= '<attr value="1">
		<attr value="name">source_dat</attr>
	</attr>';
	$tdatac_sales[".chartXml"] .= '</attr>
			<attr value="appearance">';


	$tdatac_sales[".chartXml"] .= '<attr value="head">'.xmlencode("").'</attr>
<attr value="foot">'.xmlencode("").'</attr>
<attr value="y_axis_label">'.xmlencode("").'</attr>


<attr value="slegend">true</attr>
<attr value="sgrid">true</attr>
<attr value="sname">true</attr>
<attr value="sval">true</attr>
<attr value="sanim">true</attr>
<attr value="sstacked">false</attr>
<attr value="slog">false</attr>
<attr value="aqua">0</attr>
<attr value="cview">0</attr>
<attr value="is3d">1</attr>
<attr value="isstacked">1</attr>
<attr value="linestyle">0</attr>
<attr value="autoupdate">0</attr>
<attr value="autoupmin">60</attr>';
$tdatac_sales[".chartXml"] .= '</attr>

<attr value="fields">';
	$tdatac_sales[".chartXml"] .= '<attr value="0">
		<attr value="name">source_dat</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales","source_dat")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatac_sales[".chartXml"] .= '<attr value="1">
		<attr value="name">tot_qty</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales","tot_qty")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatac_sales[".chartXml"] .= '<attr value="2">
		<attr value="name">net</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales","net")).'</attr>
		<attr value="search"></attr>
	</attr>';
$tdatac_sales[".chartXml"] .= '</attr>


<attr value="settings">
<attr value="name">c_sales</attr>
<attr value="short_table_name">c_sales</attr>
</attr>

</chart>';

$tables_data["c_sales"]=&$tdatac_sales;
$field_labels["c_sales"] = &$fieldLabelsc_sales;
$fieldToolTips["c_sales"] = &$fieldToolTipsc_sales;
$placeHolders["c_sales"] = &$placeHoldersc_sales;
$page_titles["c_sales"] = &$pageTitlesc_sales;


changeTextControlsToDate( "c_sales" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["c_sales"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["c_sales"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_c_sales()
{
$proto0=array();
$proto0["m_strHead"] = "select";
$proto0["m_strFieldList"] = "source_dat,  SUM(tot_qty) AS tot_qty,  SUM(net) AS net";
$proto0["m_strFrom"] = "FROM r_sales";
$proto0["m_strWhere"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      ))";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      ))";
$proto2["m_uniontype"] = "SQLL_AND";
	$obj = new SQLNonParsed(array(
	"m_sql" => "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      ))"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
						$proto4=array();
$proto4["m_sql"] = "date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
						$proto5=array();
$proto5["m_functiontype"] = "SQLF_CUSTOM";
$proto5["m_arguments"] = array();
						$obj = new SQLNonParsed(array(
	"m_sql" => "periode"
));

$proto5["m_arguments"][]=$obj;
						$obj = new SQLNonParsed(array(
	"m_sql" => "'%Y.%m.%d'"
));

$proto5["m_arguments"][]=$obj;
$proto5["m_strFunctionName"] = "date_format";
$obj = new SQLFunctionCall($proto5);

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = true;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

			$proto2["m_contained"][]=$obj;
						$proto8=array();
$proto8["m_sql"] = "brand_code in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      )";
$proto8["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales"
));

$proto8["m_column"]=$obj;
$proto8["m_contained"] = array();
$proto8["m_strCase"] = "in (  		select distinct brand from v_user_login_brand           where username = ':user.username'      )";
$proto8["m_havingmode"] = false;
$proto8["m_inBrackets"] = true;
$proto8["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto8);

			$proto2["m_contained"][]=$obj;
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto10=array();
$proto10["m_sql"] = "";
$proto10["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto10["m_column"]=$obj;
$proto10["m_contained"] = array();
$proto10["m_strCase"] = "";
$proto10["m_havingmode"] = false;
$proto10["m_inBrackets"] = false;
$proto10["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto10);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "source_dat",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales"
));

$proto12["m_sql"] = "source_dat";
$proto12["m_srcTableName"] = "c_sales";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$proto15=array();
$proto15["m_functiontype"] = "SQLF_SUM";
$proto15["m_arguments"] = array();
						$obj = new SQLField(array(
	"m_strName" => "tot_qty",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales"
));

$proto15["m_arguments"][]=$obj;
$proto15["m_strFunctionName"] = "SUM";
$obj = new SQLFunctionCall($proto15);

$proto14["m_sql"] = "SUM(tot_qty)";
$proto14["m_srcTableName"] = "c_sales";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "tot_qty";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$proto18=array();
$proto18["m_functiontype"] = "SQLF_SUM";
$proto18["m_arguments"] = array();
						$obj = new SQLField(array(
	"m_strName" => "net",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales"
));

$proto18["m_arguments"][]=$obj;
$proto18["m_strFunctionName"] = "SUM";
$obj = new SQLFunctionCall($proto18);

$proto17["m_sql"] = "SUM(net)";
$proto17["m_srcTableName"] = "c_sales";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "net";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto20=array();
$proto20["m_link"] = "SQLL_MAIN";
			$proto21=array();
$proto21["m_strName"] = "r_sales";
$proto21["m_srcTableName"] = "c_sales";
$proto21["m_columns"] = array();
$proto21["m_columns"][] = "id";
$proto21["m_columns"][] = "periode";
$proto21["m_columns"][] = "DIVISION";
$proto21["m_columns"][] = "SUB_DIVISION";
$proto21["m_columns"][] = "category_code";
$proto21["m_columns"][] = "DEPT";
$proto21["m_columns"][] = "SUB_DEPT";
$proto21["m_columns"][] = "brand_code";
$proto21["m_columns"][] = "brand_name";
$proto21["m_columns"][] = "barcode";
$proto21["m_columns"][] = "article_name";
$proto21["m_columns"][] = "varian_option1";
$proto21["m_columns"][] = "varian_option2";
$proto21["m_columns"][] = "price";
$proto21["m_columns"][] = "vendor_code";
$proto21["m_columns"][] = "margin";
$proto21["m_columns"][] = "tot_qty";
$proto21["m_columns"][] = "disc_pct";
$proto21["m_columns"][] = "total_disc_amt";
$proto21["m_columns"][] = "moredisc_pct";
$proto21["m_columns"][] = "total_moredisc_amt";
$proto21["m_columns"][] = "gross";
$proto21["m_columns"][] = "net";
$proto21["m_columns"][] = "gross_after_margin";
$proto21["m_columns"][] = "source_dat";
$proto21["m_columns"][] = "tag_5";
$proto21["m_columns"][] = "vendor_type";
$proto21["m_columns"][] = "fee";
$obj = new SQLTable($proto21);

$proto20["m_table"] = $obj;
$proto20["m_sql"] = "r_sales";
$proto20["m_alias"] = "";
$proto20["m_srcTableName"] = "c_sales";
$proto22=array();
$proto22["m_sql"] = "";
$proto22["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto22["m_column"]=$obj;
$proto22["m_contained"] = array();
$proto22["m_strCase"] = "";
$proto22["m_havingmode"] = false;
$proto22["m_inBrackets"] = false;
$proto22["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto22);

$proto20["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto20);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
												$proto24=array();
						$obj = new SQLField(array(
	"m_strName" => "source_dat",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales"
));

$proto24["m_column"]=$obj;
$obj = new SQLGroupByItem($proto24);

$proto0["m_groupby"][]=$obj;
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="c_sales";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_c_sales = createSqlQuery_c_sales();


	
		;

			

$tdatac_sales[".sqlquery"] = $queryData_c_sales;



$tdatac_sales[".hasEvents"] = false;

?>