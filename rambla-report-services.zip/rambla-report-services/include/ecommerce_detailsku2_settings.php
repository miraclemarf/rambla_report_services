<?php
$tdataecommerce_detailsku2 = array();
$tdataecommerce_detailsku2[".searchableFields"] = array();
$tdataecommerce_detailsku2[".ShortName"] = "ecommerce_detailsku2";
$tdataecommerce_detailsku2[".OwnerID"] = "";
$tdataecommerce_detailsku2[".OriginalTable"] = "ecommerce_detailsku2";


$tdataecommerce_detailsku2[".pagesByType"] = my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" );
$tdataecommerce_detailsku2[".originalPagesByType"] = $tdataecommerce_detailsku2[".pagesByType"];
$tdataecommerce_detailsku2[".pages"] = types2pages( my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" ) );
$tdataecommerce_detailsku2[".originalPages"] = $tdataecommerce_detailsku2[".pages"];
$tdataecommerce_detailsku2[".defaultPages"] = my_json_decode( "{\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\"}" );
$tdataecommerce_detailsku2[".originalDefaultPages"] = $tdataecommerce_detailsku2[".defaultPages"];

//	field labels
$fieldLabelsecommerce_detailsku2 = array();
$fieldToolTipsecommerce_detailsku2 = array();
$pageTitlesecommerce_detailsku2 = array();
$placeHoldersecommerce_detailsku2 = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsecommerce_detailsku2["English"] = array();
	$fieldToolTipsecommerce_detailsku2["English"] = array();
	$placeHoldersecommerce_detailsku2["English"] = array();
	$pageTitlesecommerce_detailsku2["English"] = array();
	$fieldLabelsecommerce_detailsku2["English"]["dept"] = "Dept";
	$fieldToolTipsecommerce_detailsku2["English"]["dept"] = "";
	$placeHoldersecommerce_detailsku2["English"]["dept"] = "";
	$fieldLabelsecommerce_detailsku2["English"]["brand_code"] = "Brand Code";
	$fieldToolTipsecommerce_detailsku2["English"]["brand_code"] = "";
	$placeHoldersecommerce_detailsku2["English"]["brand_code"] = "";
	if (count($fieldToolTipsecommerce_detailsku2["English"]))
		$tdataecommerce_detailsku2[".isUseToolTips"] = true;
}


	$tdataecommerce_detailsku2[".NCSearch"] = true;



$tdataecommerce_detailsku2[".shortTableName"] = "ecommerce_detailsku2";
$tdataecommerce_detailsku2[".nSecOptions"] = 0;

$tdataecommerce_detailsku2[".mainTableOwnerID"] = "";
$tdataecommerce_detailsku2[".entityType"] = 1;
$tdataecommerce_detailsku2[".connId"] = "dbcentral_at_192_168_8_99";


$tdataecommerce_detailsku2[".strOriginalTableName"] = "ecommerce_detailsku2";

	



$tdataecommerce_detailsku2[".showAddInPopup"] = false;

$tdataecommerce_detailsku2[".showEditInPopup"] = false;

$tdataecommerce_detailsku2[".showViewInPopup"] = false;

$tdataecommerce_detailsku2[".listAjax"] = false;
//	temporary
//$tdataecommerce_detailsku2[".listAjax"] = false;

	$tdataecommerce_detailsku2[".audit"] = false;

	$tdataecommerce_detailsku2[".locking"] = false;


$pages = $tdataecommerce_detailsku2[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataecommerce_detailsku2[".edit"] = true;
	$tdataecommerce_detailsku2[".afterEditAction"] = 1;
	$tdataecommerce_detailsku2[".closePopupAfterEdit"] = 1;
	$tdataecommerce_detailsku2[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataecommerce_detailsku2[".add"] = true;
$tdataecommerce_detailsku2[".afterAddAction"] = 1;
$tdataecommerce_detailsku2[".closePopupAfterAdd"] = 1;
$tdataecommerce_detailsku2[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataecommerce_detailsku2[".list"] = true;
}



$tdataecommerce_detailsku2[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataecommerce_detailsku2[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataecommerce_detailsku2[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataecommerce_detailsku2[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataecommerce_detailsku2[".printFriendly"] = true;
}



$tdataecommerce_detailsku2[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataecommerce_detailsku2[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataecommerce_detailsku2[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataecommerce_detailsku2[".isUseAjaxSuggest"] = true;





$tdataecommerce_detailsku2[".ajaxCodeSnippetAdded"] = false;

$tdataecommerce_detailsku2[".buttonsAdded"] = false;

$tdataecommerce_detailsku2[".addPageEvents"] = false;

// use timepicker for search panel
$tdataecommerce_detailsku2[".isUseTimeForSearch"] = false;


$tdataecommerce_detailsku2[".badgeColor"] = "8FBC8B";


$tdataecommerce_detailsku2[".allSearchFields"] = array();
$tdataecommerce_detailsku2[".filterFields"] = array();
$tdataecommerce_detailsku2[".requiredSearchFields"] = array();

$tdataecommerce_detailsku2[".googleLikeFields"] = array();
$tdataecommerce_detailsku2[".googleLikeFields"][] = "dept";
$tdataecommerce_detailsku2[".googleLikeFields"][] = "brand_code";



$tdataecommerce_detailsku2[".tableType"] = "list";

$tdataecommerce_detailsku2[".printerPageOrientation"] = 0;
$tdataecommerce_detailsku2[".nPrinterPageScale"] = 100;

$tdataecommerce_detailsku2[".nPrinterSplitRecords"] = 40;

$tdataecommerce_detailsku2[".geocodingEnabled"] = false;










$tdataecommerce_detailsku2[".pageSize"] = 20;

$tdataecommerce_detailsku2[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataecommerce_detailsku2[".strOrderBy"] = $tstrOrderBy;

$tdataecommerce_detailsku2[".orderindexes"] = array();


$tdataecommerce_detailsku2[".sqlHead"] = "select distinct dept, brand_code";
$tdataecommerce_detailsku2[".sqlFrom"] = "from r_sales";
$tdataecommerce_detailsku2[".sqlWhereExpr"] = "brand_code in (select brand from v_user_login_brand where username  = 'user:username')";
$tdataecommerce_detailsku2[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataecommerce_detailsku2[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataecommerce_detailsku2[".arrGroupsPerPage"] = $arrGPP;

$tdataecommerce_detailsku2[".highlightSearchResults"] = true;

$tableKeysecommerce_detailsku2 = array();
$tdataecommerce_detailsku2[".Keys"] = $tableKeysecommerce_detailsku2;


$tdataecommerce_detailsku2[".hideMobileList"] = array();




//	dept
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "dept";
	$fdata["GoodName"] = "dept";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("ecommerce_detailsku2","dept");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DEPT";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "dept";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataecommerce_detailsku2["dept"] = $fdata;
		$tdataecommerce_detailsku2[".searchableFields"][] = "dept";
//	brand_code
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "brand_code";
	$fdata["GoodName"] = "brand_code";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("ecommerce_detailsku2","brand_code");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_code";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "brand_code";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataecommerce_detailsku2["brand_code"] = $fdata;
		$tdataecommerce_detailsku2[".searchableFields"][] = "brand_code";


$tables_data["ecommerce_detailsku2"]=&$tdataecommerce_detailsku2;
$field_labels["ecommerce_detailsku2"] = &$fieldLabelsecommerce_detailsku2;
$fieldToolTips["ecommerce_detailsku2"] = &$fieldToolTipsecommerce_detailsku2;
$placeHolders["ecommerce_detailsku2"] = &$placeHoldersecommerce_detailsku2;
$page_titles["ecommerce_detailsku2"] = &$pageTitlesecommerce_detailsku2;


changeTextControlsToDate( "ecommerce_detailsku2" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["ecommerce_detailsku2"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["ecommerce_detailsku2"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_ecommerce_detailsku2()
{
$proto0=array();
$proto0["m_strHead"] = "select distinct";
$proto0["m_strFieldList"] = "dept, brand_code";
$proto0["m_strFrom"] = "from r_sales";
$proto0["m_strWhere"] = "brand_code in (select brand from v_user_login_brand where username  = 'user:username')";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "brand_code in (select brand from v_user_login_brand where username  = 'user:username')";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "ecommerce_detailsku2"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "in (select brand from v_user_login_brand where username  = 'user:username')";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "DEPT",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "ecommerce_detailsku2"
));

$proto6["m_sql"] = "dept";
$proto6["m_srcTableName"] = "ecommerce_detailsku2";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "ecommerce_detailsku2"
));

$proto8["m_sql"] = "brand_code";
$proto8["m_srcTableName"] = "ecommerce_detailsku2";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto10=array();
$proto10["m_link"] = "SQLL_MAIN";
			$proto11=array();
$proto11["m_strName"] = "r_sales";
$proto11["m_srcTableName"] = "ecommerce_detailsku2";
$proto11["m_columns"] = array();
$proto11["m_columns"][] = "id";
$proto11["m_columns"][] = "periode";
$proto11["m_columns"][] = "DIVISION";
$proto11["m_columns"][] = "SUB_DIVISION";
$proto11["m_columns"][] = "category_code";
$proto11["m_columns"][] = "DEPT";
$proto11["m_columns"][] = "SUB_DEPT";
$proto11["m_columns"][] = "brand_code";
$proto11["m_columns"][] = "brand_name";
$proto11["m_columns"][] = "barcode";
$proto11["m_columns"][] = "article_name";
$proto11["m_columns"][] = "varian_option1";
$proto11["m_columns"][] = "varian_option2";
$proto11["m_columns"][] = "price";
$proto11["m_columns"][] = "vendor_code";
$proto11["m_columns"][] = "margin";
$proto11["m_columns"][] = "tot_qty";
$proto11["m_columns"][] = "disc_pct";
$proto11["m_columns"][] = "total_disc_amt";
$proto11["m_columns"][] = "moredisc_pct";
$proto11["m_columns"][] = "total_moredisc_amt";
$proto11["m_columns"][] = "gross";
$proto11["m_columns"][] = "net";
$proto11["m_columns"][] = "gross_after_margin";
$proto11["m_columns"][] = "source_dat";
$proto11["m_columns"][] = "tag_5";
$proto11["m_columns"][] = "vendor_type";
$proto11["m_columns"][] = "fee";
$obj = new SQLTable($proto11);

$proto10["m_table"] = $obj;
$proto10["m_sql"] = "r_sales";
$proto10["m_alias"] = "";
$proto10["m_srcTableName"] = "ecommerce_detailsku2";
$proto12=array();
$proto12["m_sql"] = "";
$proto12["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto12["m_column"]=$obj;
$proto12["m_contained"] = array();
$proto12["m_strCase"] = "";
$proto12["m_havingmode"] = false;
$proto12["m_inBrackets"] = false;
$proto12["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto12);

$proto10["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto10);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="ecommerce_detailsku2";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_ecommerce_detailsku2 = createSqlQuery_ecommerce_detailsku2();


	
		;

		

$tdataecommerce_detailsku2[".sqlquery"] = $queryData_ecommerce_detailsku2;



$tdataecommerce_detailsku2[".hasEvents"] = false;

?>