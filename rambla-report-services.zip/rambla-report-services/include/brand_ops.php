<?php
$topsbrand = array();
		$topsbrand["selectList"] = array(
		"subtype" => "sql",
		"sql" => "SELECT * FROM m_brand where brand_code in ( select brand from v_user_login_brand where username = ':user.username')
"
	);
		$tables_data["Brand"][".operations"] = &$topsbrand;
?>