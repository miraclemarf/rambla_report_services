<?php
$dalTableartikel_pwp = array();
$dalTableartikel_pwp["dept"] = array("type"=>200,"varname"=>"dept", "name" => "dept", "autoInc" => "0");
$dalTableartikel_pwp["brand"] = array("type"=>200,"varname"=>"brand", "name" => "brand", "autoInc" => "0");
$dalTableartikel_pwp["code_vendor"] = array("type"=>200,"varname"=>"code_vendor", "name" => "code_vendor", "autoInc" => "0");
$dalTableartikel_pwp["barcode"] = array("type"=>200,"varname"=>"barcode", "name" => "barcode", "autoInc" => "0");
$dalTableartikel_pwp["artikel"] = array("type"=>200,"varname"=>"artikel", "name" => "artikel", "autoInc" => "0");
$dalTableartikel_pwp["warna"] = array("type"=>200,"varname"=>"warna", "name" => "warna", "autoInc" => "0");
$dalTableartikel_pwp["size"] = array("type"=>200,"varname"=>"size", "name" => "size", "autoInc" => "0");
$dalTableartikel_pwp["qty_total"] = array("type"=>2,"varname"=>"qty_total", "name" => "qty_total", "autoInc" => "0");
$dalTableartikel_pwp["harga_normal"] = array("type"=>5,"varname"=>"harga_normal", "name" => "harga_normal", "autoInc" => "0");
$dalTableartikel_pwp["promo_reguler"] = array("type"=>201,"varname"=>"promo_reguler", "name" => "promo_reguler", "autoInc" => "0");
$dalTableartikel_pwp["harga_pwp"] = array("type"=>5,"varname"=>"harga_pwp", "name" => "harga_pwp", "autoInc" => "0");
$dalTableartikel_pwp["harga_pwp_amt"] = array("type"=>5,"varname"=>"harga_pwp_amt", "name" => "harga_pwp_amt", "autoInc" => "0");
$dalTableartikel_pwp["barcode"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__artikel_pwp"] = &$dalTableartikel_pwp;
?>