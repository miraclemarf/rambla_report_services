<?php
$dalTablem_ugrights = array();
$dalTablem_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName", "autoInc" => "0");
$dalTablem_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTablem_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask", "autoInc" => "0");
$dalTablem_ugrights["Page"] = array("type"=>201,"varname"=>"Page", "name" => "Page", "autoInc" => "0");
$dalTablem_ugrights["TableName"]["key"]=true;
$dalTablem_ugrights["GroupID"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__tblm_ugrights"] = &$dalTablem_ugrights;
?>