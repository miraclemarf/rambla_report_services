<?php
$dalTablebuysmart_web_portal_locking = array();
$dalTablebuysmart_web_portal_locking["id"] = array("type"=>3,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTablebuysmart_web_portal_locking["table"] = array("type"=>200,"varname"=>"table", "name" => "table", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["startdatetime"] = array("type"=>135,"varname"=>"startdatetime", "name" => "startdatetime", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["confirmdatetime"] = array("type"=>135,"varname"=>"confirmdatetime", "name" => "confirmdatetime", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["keys"] = array("type"=>200,"varname"=>"keys", "name" => "keys", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["sessionid"] = array("type"=>200,"varname"=>"sessionid", "name" => "sessionid", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["userid"] = array("type"=>200,"varname"=>"userid", "name" => "userid", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["action"] = array("type"=>3,"varname"=>"action", "name" => "action", "autoInc" => "0");
$dalTablebuysmart_web_portal_locking["id"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__buysmart_web_portal_locking"] = &$dalTablebuysmart_web_portal_locking;
?>