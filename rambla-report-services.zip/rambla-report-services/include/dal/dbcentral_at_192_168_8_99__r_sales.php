<?php
$dalTabler_sales = array();
$dalTabler_sales["id"] = array("type"=>3,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTabler_sales["periode"] = array("type"=>200,"varname"=>"periode", "name" => "periode", "autoInc" => "0");
$dalTabler_sales["DIVISION"] = array("type"=>200,"varname"=>"DIVISION", "name" => "DIVISION", "autoInc" => "0");
$dalTabler_sales["SUB_DIVISION"] = array("type"=>200,"varname"=>"SUB_DIVISION", "name" => "SUB_DIVISION", "autoInc" => "0");
$dalTabler_sales["category_code"] = array("type"=>200,"varname"=>"category_code", "name" => "category_code", "autoInc" => "0");
$dalTabler_sales["DEPT"] = array("type"=>200,"varname"=>"DEPT", "name" => "DEPT", "autoInc" => "0");
$dalTabler_sales["SUB_DEPT"] = array("type"=>200,"varname"=>"SUB_DEPT", "name" => "SUB_DEPT", "autoInc" => "0");
$dalTabler_sales["brand_code"] = array("type"=>200,"varname"=>"brand_code", "name" => "brand_code", "autoInc" => "0");
$dalTabler_sales["brand_name"] = array("type"=>200,"varname"=>"brand_name", "name" => "brand_name", "autoInc" => "0");
$dalTabler_sales["barcode"] = array("type"=>200,"varname"=>"barcode", "name" => "barcode", "autoInc" => "0");
$dalTabler_sales["article_name"] = array("type"=>200,"varname"=>"article_name", "name" => "article_name", "autoInc" => "0");
$dalTabler_sales["varian_option1"] = array("type"=>200,"varname"=>"varian_option1", "name" => "varian_option1", "autoInc" => "0");
$dalTabler_sales["varian_option2"] = array("type"=>200,"varname"=>"varian_option2", "name" => "varian_option2", "autoInc" => "0");
$dalTabler_sales["price"] = array("type"=>5,"varname"=>"price", "name" => "price", "autoInc" => "0");
$dalTabler_sales["vendor_code"] = array("type"=>200,"varname"=>"vendor_code", "name" => "vendor_code", "autoInc" => "0");
$dalTabler_sales["margin"] = array("type"=>5,"varname"=>"margin", "name" => "margin", "autoInc" => "0");
$dalTabler_sales["tot_qty"] = array("type"=>3,"varname"=>"tot_qty", "name" => "tot_qty", "autoInc" => "0");
$dalTabler_sales["disc_pct"] = array("type"=>5,"varname"=>"disc_pct", "name" => "disc_pct", "autoInc" => "0");
$dalTabler_sales["total_disc_amt"] = array("type"=>5,"varname"=>"total_disc_amt", "name" => "total_disc_amt", "autoInc" => "0");
$dalTabler_sales["moredisc_pct"] = array("type"=>5,"varname"=>"moredisc_pct", "name" => "moredisc_pct", "autoInc" => "0");
$dalTabler_sales["total_moredisc_amt"] = array("type"=>5,"varname"=>"total_moredisc_amt", "name" => "total_moredisc_amt", "autoInc" => "0");
$dalTabler_sales["gross"] = array("type"=>5,"varname"=>"gross", "name" => "gross", "autoInc" => "0");
$dalTabler_sales["net"] = array("type"=>5,"varname"=>"net", "name" => "net", "autoInc" => "0");
$dalTabler_sales["gross_after_margin"] = array("type"=>5,"varname"=>"gross_after_margin", "name" => "gross_after_margin", "autoInc" => "0");
$dalTabler_sales["source_dat"] = array("type"=>200,"varname"=>"source_dat", "name" => "source_dat", "autoInc" => "0");
$dalTabler_sales["tag_5"] = array("type"=>200,"varname"=>"tag_5", "name" => "tag_5", "autoInc" => "0");
$dalTabler_sales["vendor_type"] = array("type"=>200,"varname"=>"vendor_type", "name" => "vendor_type", "autoInc" => "0");
$dalTabler_sales["fee"] = array("type"=>5,"varname"=>"fee", "name" => "fee", "autoInc" => "0");
$dalTabler_sales["id"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__r_sales"] = &$dalTabler_sales;
?>