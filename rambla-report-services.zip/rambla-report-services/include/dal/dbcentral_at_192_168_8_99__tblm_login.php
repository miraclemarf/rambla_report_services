<?php
$dalTablem_login = array();
$dalTablem_login["loginID"] = array("type"=>3,"varname"=>"loginID", "name" => "loginID", "autoInc" => "1");
$dalTablem_login["login_type_id"] = array("type"=>3,"varname"=>"login_type_id", "name" => "login_type_id", "autoInc" => "0");
$dalTablem_login["username"] = array("type"=>200,"varname"=>"username", "name" => "username", "autoInc" => "0");
$dalTablem_login["password"] = array("type"=>200,"varname"=>"password", "name" => "password", "autoInc" => "0");
$dalTablem_login["email"] = array("type"=>200,"varname"=>"email", "name" => "email", "autoInc" => "0");
$dalTablem_login["images"] = array("type"=>200,"varname"=>"images", "name" => "images", "autoInc" => "0");
$dalTablem_login["firstlogin"] = array("type"=>3,"varname"=>"firstlogin", "name" => "firstlogin", "autoInc" => "0");
$dalTablem_login["update_login_date"] = array("type"=>135,"varname"=>"update_login_date", "name" => "update_login_date", "autoInc" => "0");
$dalTablem_login["last_login_date"] = array("type"=>135,"varname"=>"last_login_date", "name" => "last_login_date", "autoInc" => "0");
$dalTablem_login["loginStatus"] = array("type"=>3,"varname"=>"loginStatus", "name" => "loginStatus", "autoInc" => "0");
$dalTablem_login["role_id"] = array("type"=>200,"varname"=>"role_id", "name" => "role_id", "autoInc" => "0");
$dalTablem_login["app_id"] = array("type"=>3,"varname"=>"app_id", "name" => "app_id", "autoInc" => "0");
$dalTablem_login["token"] = array("type"=>200,"varname"=>"token", "name" => "token", "autoInc" => "0");
$dalTablem_login["userpic"] = array("type"=>128,"varname"=>"userpic", "name" => "userpic", "autoInc" => "0");
$dalTablem_login["lat"] = array("type"=>5,"varname"=>"lat", "name" => "lat", "autoInc" => "0");
$dalTablem_login["lng"] = array("type"=>5,"varname"=>"lng", "name" => "lng", "autoInc" => "0");
$dalTablem_login["cardcode"] = array("type"=>200,"varname"=>"cardcode", "name" => "cardcode", "autoInc" => "0");
$dalTablem_login["reset_token"] = array("type"=>201,"varname"=>"reset_token", "name" => "reset_token", "autoInc" => "0");
$dalTablem_login["reset_date"] = array("type"=>135,"varname"=>"reset_date", "name" => "reset_date", "autoInc" => "0");
$dalTablem_login["user_ldap"] = array("type"=>200,"varname"=>"user_ldap", "name" => "user_ldap", "autoInc" => "0");
$dalTablem_login["apikey"] = array("type"=>200,"varname"=>"apikey", "name" => "apikey", "autoInc" => "0");
$dalTablem_login["two_factor"] = array("type"=>3,"varname"=>"two_factor", "name" => "two_factor", "autoInc" => "0");
$dalTablem_login["two_factor1"] = array("type"=>3,"varname"=>"two_factor1", "name" => "two_factor1", "autoInc" => "0");
$dalTablem_login["loginID"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__tblm_login"] = &$dalTablem_login;
?>