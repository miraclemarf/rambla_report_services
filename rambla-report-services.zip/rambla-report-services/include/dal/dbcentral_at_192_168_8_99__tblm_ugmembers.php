<?php
$dalTablem_ugmembers = array();
$dalTablem_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName", "name" => "UserName", "autoInc" => "0");
$dalTablem_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTablem_ugmembers["Provider"] = array("type"=>200,"varname"=>"Provider", "name" => "Provider", "autoInc" => "0");
$dalTablem_ugmembers["UserName"]["key"]=true;
$dalTablem_ugmembers["GroupID"]["key"]=true;
$dalTablem_ugmembers["Provider"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__tblm_ugmembers"] = &$dalTablem_ugmembers;
?>