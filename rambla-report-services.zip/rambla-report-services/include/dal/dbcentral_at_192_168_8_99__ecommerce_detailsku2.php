<?php
$dalTableecommerce_detailsku2 = array();
$dalTableecommerce_detailsku2["article_code"] = array("type"=>201,"varname"=>"article_code", "name" => "article_code", "autoInc" => "0");
$dalTableecommerce_detailsku2["article_name"] = array("type"=>201,"varname"=>"article_name", "name" => "article_name", "autoInc" => "0");
$dalTableecommerce_detailsku2["berat"] = array("type"=>14,"varname"=>"berat", "name" => "berat", "autoInc" => "0");
$dalTableecommerce_detailsku2["code_brand"] = array("type"=>201,"varname"=>"code_brand", "name" => "code_brand", "autoInc" => "0");
$dalTableecommerce_detailsku2["deskripsi"] = array("type"=>201,"varname"=>"deskripsi", "name" => "deskripsi", "autoInc" => "0");
$dalTableecommerce_detailsku2["kode_varian1"] = array("type"=>201,"varname"=>"kode_varian1", "name" => "kode_varian1", "autoInc" => "0");
$dalTableecommerce_detailsku2["kode_varian2"] = array("type"=>201,"varname"=>"kode_varian2", "name" => "kode_varian2", "autoInc" => "0");
$dalTableecommerce_detailsku2["kode_varian3"] = array("type"=>201,"varname"=>"kode_varian3", "name" => "kode_varian3", "autoInc" => "0");
$dalTableecommerce_detailsku2["lebar"] = array("type"=>3,"varname"=>"lebar", "name" => "lebar", "autoInc" => "0");
$dalTableecommerce_detailsku2["nama_brand"] = array("type"=>201,"varname"=>"nama_brand", "name" => "nama_brand", "autoInc" => "0");
$dalTableecommerce_detailsku2["nama_varian1"] = array("type"=>201,"varname"=>"nama_varian1", "name" => "nama_varian1", "autoInc" => "0");
$dalTableecommerce_detailsku2["nama_varian2"] = array("type"=>201,"varname"=>"nama_varian2", "name" => "nama_varian2", "autoInc" => "0");
$dalTableecommerce_detailsku2["nama_varian3"] = array("type"=>201,"varname"=>"nama_varian3", "name" => "nama_varian3", "autoInc" => "0");
$dalTableecommerce_detailsku2["panjang"] = array("type"=>3,"varname"=>"panjang", "name" => "panjang", "autoInc" => "0");
$dalTableecommerce_detailsku2["sku_code"] = array("type"=>201,"varname"=>"sku_code", "name" => "sku_code", "autoInc" => "0");
$dalTableecommerce_detailsku2["supplier_code"] = array("type"=>201,"varname"=>"supplier_code", "name" => "supplier_code", "autoInc" => "0");
$dalTableecommerce_detailsku2["supplier_name"] = array("type"=>201,"varname"=>"supplier_name", "name" => "supplier_name", "autoInc" => "0");
$dalTableecommerce_detailsku2["tinggi"] = array("type"=>3,"varname"=>"tinggi", "name" => "tinggi", "autoInc" => "0");

$dal_info["dbcentral_at_192_168_8_99__ecommerce_detailsku2"] = &$dalTableecommerce_detailsku2;
?>