<?php
$dalTablem_brand = array();
$dalTablem_brand["brand_code"] = array("type"=>200,"varname"=>"brand_code", "name" => "brand_code", "autoInc" => "0");
$dalTablem_brand["brand_name"] = array("type"=>200,"varname"=>"brand_name", "name" => "brand_name", "autoInc" => "0");
$dalTablem_brand["brand_group"] = array("type"=>200,"varname"=>"brand_group", "name" => "brand_group", "autoInc" => "0");
$dalTablem_brand["sm"] = array("type"=>200,"varname"=>"sm", "name" => "sm", "autoInc" => "0");
$dalTablem_brand["brand_code"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__tblm_brand"] = &$dalTablem_brand;
?>