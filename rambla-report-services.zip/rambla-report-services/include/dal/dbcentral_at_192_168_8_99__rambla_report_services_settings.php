<?php
$dalTablerambla_report_services_settings = array();
$dalTablerambla_report_services_settings["ID"] = array("type"=>3,"varname"=>"ID", "name" => "ID", "autoInc" => "1");
$dalTablerambla_report_services_settings["TYPE"] = array("type"=>3,"varname"=>"TYPE", "name" => "TYPE", "autoInc" => "0");
$dalTablerambla_report_services_settings["NAME"] = array("type"=>201,"varname"=>"NAME", "name" => "NAME", "autoInc" => "0");
$dalTablerambla_report_services_settings["USERNAME"] = array("type"=>201,"varname"=>"USERNAME", "name" => "USERNAME", "autoInc" => "0");
$dalTablerambla_report_services_settings["COOKIE"] = array("type"=>200,"varname"=>"COOKIE", "name" => "COOKIE", "autoInc" => "0");
$dalTablerambla_report_services_settings["SEARCH"] = array("type"=>201,"varname"=>"SEARCH", "name" => "SEARCH", "autoInc" => "0");
$dalTablerambla_report_services_settings["TABLENAME"] = array("type"=>200,"varname"=>"TABLENAME", "name" => "TABLENAME", "autoInc" => "0");
$dalTablerambla_report_services_settings["ID"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__rambla_report_services_settings"] = &$dalTablerambla_report_services_settings;
?>