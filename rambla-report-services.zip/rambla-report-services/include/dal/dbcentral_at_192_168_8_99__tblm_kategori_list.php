<?php
$dalTablem_kategori_list = array();
$dalTablem_kategori_list["seq"] = array("type"=>3,"varname"=>"seq", "name" => "seq", "autoInc" => "1");
$dalTablem_kategori_list["KODE_DIVISION"] = array("type"=>200,"varname"=>"KODE_DIVISION", "name" => "KODE_DIVISION", "autoInc" => "0");
$dalTablem_kategori_list["DIVISION"] = array("type"=>200,"varname"=>"DIVISION", "name" => "DIVISION", "autoInc" => "0");
$dalTablem_kategori_list["KODE_SUB_DIVISION"] = array("type"=>200,"varname"=>"KODE_SUB_DIVISION", "name" => "KODE_SUB_DIVISION", "autoInc" => "0");
$dalTablem_kategori_list["SUB_DIVISION"] = array("type"=>200,"varname"=>"SUB_DIVISION", "name" => "SUB_DIVISION", "autoInc" => "0");
$dalTablem_kategori_list["KODE_DEPT"] = array("type"=>200,"varname"=>"KODE_DEPT", "name" => "KODE_DEPT", "autoInc" => "0");
$dalTablem_kategori_list["DEPT"] = array("type"=>200,"varname"=>"DEPT", "name" => "DEPT", "autoInc" => "0");
$dalTablem_kategori_list["KODE_SUB_DEPT"] = array("type"=>200,"varname"=>"KODE_SUB_DEPT", "name" => "KODE_SUB_DEPT", "autoInc" => "0");
$dalTablem_kategori_list["SUB_DEPT"] = array("type"=>200,"varname"=>"SUB_DEPT", "name" => "SUB_DEPT", "autoInc" => "0");
$dalTablem_kategori_list["KODE_CATEGORY"] = array("type"=>200,"varname"=>"KODE_CATEGORY", "name" => "KODE_CATEGORY", "autoInc" => "0");
$dalTablem_kategori_list["CATEGORY"] = array("type"=>200,"varname"=>"CATEGORY", "name" => "CATEGORY", "autoInc" => "0");
$dalTablem_kategori_list["CATEGORY_CODE"] = array("type"=>200,"varname"=>"CATEGORY_CODE", "name" => "CATEGORY_CODE", "autoInc" => "0");
$dalTablem_kategori_list["seq"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__tblm_kategori_list"] = &$dalTablem_kategori_list;
?>