<?php
$dalTables_item_stok = array();
$dalTables_item_stok["period"] = array("type"=>135,"varname"=>"period", "name" => "period", "autoInc" => "0");
$dalTables_item_stok["article_code"] = array("type"=>200,"varname"=>"article_code", "name" => "article_code", "autoInc" => "0");
$dalTables_item_stok["article_number"] = array("type"=>200,"varname"=>"article_number", "name" => "article_number", "autoInc" => "0");
$dalTables_item_stok["barcode"] = array("type"=>200,"varname"=>"barcode", "name" => "barcode", "autoInc" => "0");
$dalTables_item_stok["sku_code"] = array("type"=>200,"varname"=>"sku_code", "name" => "sku_code", "autoInc" => "0");
$dalTables_item_stok["supplier_pcode"] = array("type"=>200,"varname"=>"supplier_pcode", "name" => "supplier_pcode", "autoInc" => "0");
$dalTables_item_stok["first_stock"] = array("type"=>3,"varname"=>"first_stock", "name" => "first_stock", "autoInc" => "0");
$dalTables_item_stok["receipt"] = array("type"=>3,"varname"=>"receipt", "name" => "receipt", "autoInc" => "0");
$dalTables_item_stok["issue"] = array("type"=>3,"varname"=>"issue", "name" => "issue", "autoInc" => "0");
$dalTables_item_stok["sales"] = array("type"=>3,"varname"=>"sales", "name" => "sales", "autoInc" => "0");
$dalTables_item_stok["refund"] = array("type"=>3,"varname"=>"refund", "name" => "refund", "autoInc" => "0");
$dalTables_item_stok["adj_in"] = array("type"=>3,"varname"=>"adj_in", "name" => "adj_in", "autoInc" => "0");
$dalTables_item_stok["adj_out"] = array("type"=>3,"varname"=>"adj_out", "name" => "adj_out", "autoInc" => "0");
$dalTables_item_stok["transfer_in"] = array("type"=>3,"varname"=>"transfer_in", "name" => "transfer_in", "autoInc" => "0");
$dalTables_item_stok["transfer_out"] = array("type"=>3,"varname"=>"transfer_out", "name" => "transfer_out", "autoInc" => "0");
$dalTables_item_stok["last_stock"] = array("type"=>3,"varname"=>"last_stock", "name" => "last_stock", "autoInc" => "0");
$dalTables_item_stok["on_hold"] = array("type"=>3,"varname"=>"on_hold", "name" => "on_hold", "autoInc" => "0");
$dalTables_item_stok["transit"] = array("type"=>3,"varname"=>"transit", "name" => "transit", "autoInc" => "0");
$dalTables_item_stok["period"]["key"]=true;
$dalTables_item_stok["article_number"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__s_item_stok"] = &$dalTables_item_stok;
?>