<?php
$dalTableecommerce_invbranch2 = array();
$dalTableecommerce_invbranch2["branch"] = array("type"=>201,"varname"=>"branch", "name" => "branch", "autoInc" => "0");
$dalTableecommerce_invbranch2["publish"] = array("type"=>201,"varname"=>"publish", "name" => "publish", "autoInc" => "0");
$dalTableecommerce_invbranch2["sku_code"] = array("type"=>200,"varname"=>"sku_code", "name" => "sku_code", "autoInc" => "0");
$dalTableecommerce_invbranch2["stock"] = array("type"=>201,"varname"=>"stock", "name" => "stock", "autoInc" => "0");
$dalTableecommerce_invbranch2["sku_code"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__ecommerce_invbranch2"] = &$dalTableecommerce_invbranch2;
?>