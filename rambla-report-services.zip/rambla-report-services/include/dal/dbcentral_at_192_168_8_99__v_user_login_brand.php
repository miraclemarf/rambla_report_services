<?php
$dalTablev_user_login_brand = array();
$dalTablev_user_login_brand["brand"] = array("type"=>200,"varname"=>"brand", "name" => "brand", "autoInc" => "0");
$dalTablev_user_login_brand["brand_name"] = array("type"=>200,"varname"=>"brand_name", "name" => "brand_name", "autoInc" => "0");
$dalTablev_user_login_brand["category_code"] = array("type"=>200,"varname"=>"category_code", "name" => "category_code", "autoInc" => "0");
$dalTablev_user_login_brand["username"] = array("type"=>200,"varname"=>"username", "name" => "username", "autoInc" => "0");
$dalTablev_user_login_brand["vendor_code"] = array("type"=>200,"varname"=>"vendor_code", "name" => "vendor_code", "autoInc" => "0");

$dal_info["dbcentral_at_192_168_8_99__v_user_login_brand"] = &$dalTablev_user_login_brand;
?>