<?php
$dalTablet_promo_type = array();
$dalTablet_promo_type["promo_type"] = array("type"=>200,"varname"=>"promo_type", "name" => "promo_type", "autoInc" => "0");
$dalTablet_promo_type["promo_name"] = array("type"=>200,"varname"=>"promo_name", "name" => "promo_name", "autoInc" => "0");
$dalTablet_promo_type["tipe"] = array("type"=>16,"varname"=>"tipe", "name" => "tipe", "autoInc" => "0");
$dalTablet_promo_type["online"] = array("type"=>200,"varname"=>"online", "name" => "online", "autoInc" => "0");
$dalTablet_promo_type["offline"] = array("type"=>200,"varname"=>"offline", "name" => "offline", "autoInc" => "0");
$dalTablet_promo_type["member_only"] = array("type"=>200,"varname"=>"member_only", "name" => "member_only", "autoInc" => "0");
$dalTablet_promo_type["issegment"] = array("type"=>200,"varname"=>"issegment", "name" => "issegment", "autoInc" => "0");
$dalTablet_promo_type["seqment_id"] = array("type"=>200,"varname"=>"seqment_id", "name" => "seqment_id", "autoInc" => "0");
$dalTablet_promo_type["isaktif"] = array("type"=>200,"varname"=>"isaktif", "name" => "isaktif", "autoInc" => "0");
$dalTablet_promo_type["promo_type"]["key"]=true;

$dal_info["dbcentral_at_192_168_8_99__t_promo_type"] = &$dalTablet_promo_type;
?>