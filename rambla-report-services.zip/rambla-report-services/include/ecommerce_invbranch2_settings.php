<?php
$tdataecommerce_invbranch2 = array();
$tdataecommerce_invbranch2[".searchableFields"] = array();
$tdataecommerce_invbranch2[".ShortName"] = "ecommerce_invbranch2";
$tdataecommerce_invbranch2[".OwnerID"] = "";
$tdataecommerce_invbranch2[".OriginalTable"] = "ecommerce_invbranch2";


$tdataecommerce_invbranch2[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" );
$tdataecommerce_invbranch2[".originalPagesByType"] = $tdataecommerce_invbranch2[".pagesByType"];
$tdataecommerce_invbranch2[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" ) );
$tdataecommerce_invbranch2[".originalPages"] = $tdataecommerce_invbranch2[".pages"];
$tdataecommerce_invbranch2[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\"}" );
$tdataecommerce_invbranch2[".originalDefaultPages"] = $tdataecommerce_invbranch2[".defaultPages"];

//	field labels
$fieldLabelsecommerce_invbranch2 = array();
$fieldToolTipsecommerce_invbranch2 = array();
$pageTitlesecommerce_invbranch2 = array();
$placeHoldersecommerce_invbranch2 = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsecommerce_invbranch2["English"] = array();
	$fieldToolTipsecommerce_invbranch2["English"] = array();
	$placeHoldersecommerce_invbranch2["English"] = array();
	$pageTitlesecommerce_invbranch2["English"] = array();
	$fieldLabelsecommerce_invbranch2["English"]["dept"] = "Dept";
	$fieldToolTipsecommerce_invbranch2["English"]["dept"] = "";
	$placeHoldersecommerce_invbranch2["English"]["dept"] = "";
	if (count($fieldToolTipsecommerce_invbranch2["English"]))
		$tdataecommerce_invbranch2[".isUseToolTips"] = true;
}


	$tdataecommerce_invbranch2[".NCSearch"] = true;



$tdataecommerce_invbranch2[".shortTableName"] = "ecommerce_invbranch2";
$tdataecommerce_invbranch2[".nSecOptions"] = 0;

$tdataecommerce_invbranch2[".mainTableOwnerID"] = "";
$tdataecommerce_invbranch2[".entityType"] = 1;
$tdataecommerce_invbranch2[".connId"] = "dbcentral_at_192_168_8_99";


$tdataecommerce_invbranch2[".strOriginalTableName"] = "ecommerce_invbranch2";

	



$tdataecommerce_invbranch2[".showAddInPopup"] = false;

$tdataecommerce_invbranch2[".showEditInPopup"] = false;

$tdataecommerce_invbranch2[".showViewInPopup"] = false;

$tdataecommerce_invbranch2[".listAjax"] = false;
//	temporary
//$tdataecommerce_invbranch2[".listAjax"] = false;

	$tdataecommerce_invbranch2[".audit"] = false;

	$tdataecommerce_invbranch2[".locking"] = false;


$pages = $tdataecommerce_invbranch2[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataecommerce_invbranch2[".edit"] = true;
	$tdataecommerce_invbranch2[".afterEditAction"] = 1;
	$tdataecommerce_invbranch2[".closePopupAfterEdit"] = 1;
	$tdataecommerce_invbranch2[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataecommerce_invbranch2[".add"] = true;
$tdataecommerce_invbranch2[".afterAddAction"] = 1;
$tdataecommerce_invbranch2[".closePopupAfterAdd"] = 1;
$tdataecommerce_invbranch2[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataecommerce_invbranch2[".list"] = true;
}



$tdataecommerce_invbranch2[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataecommerce_invbranch2[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataecommerce_invbranch2[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataecommerce_invbranch2[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataecommerce_invbranch2[".printFriendly"] = true;
}



$tdataecommerce_invbranch2[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataecommerce_invbranch2[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataecommerce_invbranch2[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataecommerce_invbranch2[".isUseAjaxSuggest"] = true;





$tdataecommerce_invbranch2[".ajaxCodeSnippetAdded"] = false;

$tdataecommerce_invbranch2[".buttonsAdded"] = false;

$tdataecommerce_invbranch2[".addPageEvents"] = false;

// use timepicker for search panel
$tdataecommerce_invbranch2[".isUseTimeForSearch"] = false;


$tdataecommerce_invbranch2[".badgeColor"] = "1E90FF";


$tdataecommerce_invbranch2[".allSearchFields"] = array();
$tdataecommerce_invbranch2[".filterFields"] = array();
$tdataecommerce_invbranch2[".requiredSearchFields"] = array();

$tdataecommerce_invbranch2[".googleLikeFields"] = array();
$tdataecommerce_invbranch2[".googleLikeFields"][] = "dept";



$tdataecommerce_invbranch2[".tableType"] = "list";

$tdataecommerce_invbranch2[".printerPageOrientation"] = 0;
$tdataecommerce_invbranch2[".nPrinterPageScale"] = 100;

$tdataecommerce_invbranch2[".nPrinterSplitRecords"] = 40;

$tdataecommerce_invbranch2[".geocodingEnabled"] = false;










$tdataecommerce_invbranch2[".pageSize"] = 20;

$tdataecommerce_invbranch2[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataecommerce_invbranch2[".strOrderBy"] = $tstrOrderBy;

$tdataecommerce_invbranch2[".orderindexes"] = array();


$tdataecommerce_invbranch2[".sqlHead"] = "select distinct dept";
$tdataecommerce_invbranch2[".sqlFrom"] = "from r_sales";
$tdataecommerce_invbranch2[".sqlWhereExpr"] = "brand_code in (select brand from v_user_login_brand where username = ':user.username')";
$tdataecommerce_invbranch2[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataecommerce_invbranch2[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataecommerce_invbranch2[".arrGroupsPerPage"] = $arrGPP;

$tdataecommerce_invbranch2[".highlightSearchResults"] = true;

$tableKeysecommerce_invbranch2 = array();
$tdataecommerce_invbranch2[".Keys"] = $tableKeysecommerce_invbranch2;


$tdataecommerce_invbranch2[".hideMobileList"] = array();




//	dept
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "dept";
	$fdata["GoodName"] = "dept";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("ecommerce_invbranch2","dept");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DEPT";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "dept";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataecommerce_invbranch2["dept"] = $fdata;
		$tdataecommerce_invbranch2[".searchableFields"][] = "dept";


$tables_data["ecommerce_invbranch2"]=&$tdataecommerce_invbranch2;
$field_labels["ecommerce_invbranch2"] = &$fieldLabelsecommerce_invbranch2;
$fieldToolTips["ecommerce_invbranch2"] = &$fieldToolTipsecommerce_invbranch2;
$placeHolders["ecommerce_invbranch2"] = &$placeHoldersecommerce_invbranch2;
$page_titles["ecommerce_invbranch2"] = &$pageTitlesecommerce_invbranch2;


changeTextControlsToDate( "ecommerce_invbranch2" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["ecommerce_invbranch2"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["ecommerce_invbranch2"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_ecommerce_invbranch2()
{
$proto0=array();
$proto0["m_strHead"] = "select distinct";
$proto0["m_strFieldList"] = "dept";
$proto0["m_strFrom"] = "from r_sales";
$proto0["m_strWhere"] = "brand_code in (select brand from v_user_login_brand where username = ':user.username')";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "brand_code in (select brand from v_user_login_brand where username = ':user.username')";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "ecommerce_invbranch2"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "in (select brand from v_user_login_brand where username = ':user.username')";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "DEPT",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "ecommerce_invbranch2"
));

$proto6["m_sql"] = "dept";
$proto6["m_srcTableName"] = "ecommerce_invbranch2";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto8=array();
$proto8["m_link"] = "SQLL_MAIN";
			$proto9=array();
$proto9["m_strName"] = "r_sales";
$proto9["m_srcTableName"] = "ecommerce_invbranch2";
$proto9["m_columns"] = array();
$proto9["m_columns"][] = "id";
$proto9["m_columns"][] = "periode";
$proto9["m_columns"][] = "DIVISION";
$proto9["m_columns"][] = "SUB_DIVISION";
$proto9["m_columns"][] = "category_code";
$proto9["m_columns"][] = "DEPT";
$proto9["m_columns"][] = "SUB_DEPT";
$proto9["m_columns"][] = "brand_code";
$proto9["m_columns"][] = "brand_name";
$proto9["m_columns"][] = "barcode";
$proto9["m_columns"][] = "article_name";
$proto9["m_columns"][] = "varian_option1";
$proto9["m_columns"][] = "varian_option2";
$proto9["m_columns"][] = "price";
$proto9["m_columns"][] = "vendor_code";
$proto9["m_columns"][] = "margin";
$proto9["m_columns"][] = "tot_qty";
$proto9["m_columns"][] = "disc_pct";
$proto9["m_columns"][] = "total_disc_amt";
$proto9["m_columns"][] = "moredisc_pct";
$proto9["m_columns"][] = "total_moredisc_amt";
$proto9["m_columns"][] = "gross";
$proto9["m_columns"][] = "net";
$proto9["m_columns"][] = "gross_after_margin";
$proto9["m_columns"][] = "source_dat";
$proto9["m_columns"][] = "tag_5";
$proto9["m_columns"][] = "vendor_type";
$proto9["m_columns"][] = "fee";
$obj = new SQLTable($proto9);

$proto8["m_table"] = $obj;
$proto8["m_sql"] = "r_sales";
$proto8["m_alias"] = "";
$proto8["m_srcTableName"] = "ecommerce_invbranch2";
$proto10=array();
$proto10["m_sql"] = "";
$proto10["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto10["m_column"]=$obj;
$proto10["m_contained"] = array();
$proto10["m_strCase"] = "";
$proto10["m_havingmode"] = false;
$proto10["m_inBrackets"] = false;
$proto10["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto10);

$proto8["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto8);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="ecommerce_invbranch2";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_ecommerce_invbranch2 = createSqlQuery_ecommerce_invbranch2();


	
		;

	

$tdataecommerce_invbranch2[".sqlquery"] = $queryData_ecommerce_invbranch2;



$tdataecommerce_invbranch2[".hasEvents"] = false;

?>