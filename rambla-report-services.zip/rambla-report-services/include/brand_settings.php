<?php
$tdatabrand = array();
$tdatabrand[".searchableFields"] = array();
$tdatabrand[".ShortName"] = "brand";
$tdatabrand[".OwnerID"] = "";
$tdatabrand[".OriginalTable"] = "Brand";


$tdatabrand[".pagesByType"] = my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" );
$tdatabrand[".originalPagesByType"] = $tdatabrand[".pagesByType"];
$tdatabrand[".pages"] = types2pages( my_json_decode( "{\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"]}" ) );
$tdatabrand[".originalPages"] = $tdatabrand[".pages"];
$tdatabrand[".defaultPages"] = my_json_decode( "{\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\"}" );
$tdatabrand[".originalDefaultPages"] = $tdatabrand[".defaultPages"];

//	field labels
$fieldLabelsbrand = array();
$fieldToolTipsbrand = array();
$pageTitlesbrand = array();
$placeHoldersbrand = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsbrand["English"] = array();
	$fieldToolTipsbrand["English"] = array();
	$placeHoldersbrand["English"] = array();
	$pageTitlesbrand["English"] = array();
	$fieldLabelsbrand["English"]["brand_code"] = "Brand Code";
	$fieldToolTipsbrand["English"]["brand_code"] = "";
	$placeHoldersbrand["English"]["brand_code"] = "";
	$fieldLabelsbrand["English"]["brand_name"] = "Brand Name";
	$fieldToolTipsbrand["English"]["brand_name"] = "";
	$placeHoldersbrand["English"]["brand_name"] = "";
	if (count($fieldToolTipsbrand["English"]))
		$tdatabrand[".isUseToolTips"] = true;
}


	$tdatabrand[".NCSearch"] = true;



$tdatabrand[".shortTableName"] = "brand";
$tdatabrand[".nSecOptions"] = 0;

$tdatabrand[".mainTableOwnerID"] = "";
$tdatabrand[".entityType"] = 6;
$tdatabrand[".connId"] = "dbcentral_at_192_168_8_99";


$tdatabrand[".strOriginalTableName"] = "Brand";

	



$tdatabrand[".showAddInPopup"] = false;

$tdatabrand[".showEditInPopup"] = false;

$tdatabrand[".showViewInPopup"] = false;

$tdatabrand[".listAjax"] = false;
//	temporary
//$tdatabrand[".listAjax"] = false;

	$tdatabrand[".audit"] = false;

	$tdatabrand[".locking"] = false;


$pages = $tdatabrand[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatabrand[".edit"] = true;
	$tdatabrand[".afterEditAction"] = 1;
	$tdatabrand[".closePopupAfterEdit"] = 1;
	$tdatabrand[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatabrand[".add"] = true;
$tdatabrand[".afterAddAction"] = 1;
$tdatabrand[".closePopupAfterAdd"] = 1;
$tdatabrand[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatabrand[".list"] = true;
}



$tdatabrand[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatabrand[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatabrand[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatabrand[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatabrand[".printFriendly"] = true;
}



$tdatabrand[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatabrand[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatabrand[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatabrand[".isUseAjaxSuggest"] = true;





$tdatabrand[".ajaxCodeSnippetAdded"] = false;

$tdatabrand[".buttonsAdded"] = false;

$tdatabrand[".addPageEvents"] = false;

// use timepicker for search panel
$tdatabrand[".isUseTimeForSearch"] = false;


$tdatabrand[".badgeColor"] = "778899";


$tdatabrand[".allSearchFields"] = array();
$tdatabrand[".filterFields"] = array();
$tdatabrand[".requiredSearchFields"] = array();

$tdatabrand[".googleLikeFields"] = array();
$tdatabrand[".googleLikeFields"][] = "brand_code";
$tdatabrand[".googleLikeFields"][] = "brand_name";




$tdatabrand[".printerPageOrientation"] = 0;
$tdatabrand[".nPrinterPageScale"] = 100;

$tdatabrand[".nPrinterSplitRecords"] = 40;

$tdatabrand[".geocodingEnabled"] = false;










$tdatabrand[".pageSize"] = 20;

$tdatabrand[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdatabrand[".strOrderBy"] = $tstrOrderBy;

$tdatabrand[".orderindexes"] = array();


$tdatabrand[".sqlHead"] = "";
$tdatabrand[".sqlFrom"] = "";
$tdatabrand[".sqlWhereExpr"] = "";
$tdatabrand[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatabrand[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatabrand[".arrGroupsPerPage"] = $arrGPP;

$tdatabrand[".highlightSearchResults"] = true;

$tableKeysbrand = array();
$tableKeysbrand[] = "brand_code";
$tdatabrand[".Keys"] = $tableKeysbrand;


$tdatabrand[".hideMobileList"] = array();




//	brand_code
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "brand_code";
	$fdata["GoodName"] = "brand_code";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("Brand","brand_code");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_code";

	
		$fdata["FullName"] = "brand_code";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatabrand["brand_code"] = $fdata;
		$tdatabrand[".searchableFields"][] = "brand_code";
//	brand_name
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "brand_name";
	$fdata["GoodName"] = "brand_name";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("Brand","brand_name");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_name";

	
		$fdata["FullName"] = "brand_name";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatabrand["brand_name"] = $fdata;
		$tdatabrand[".searchableFields"][] = "brand_name";


$tables_data["Brand"]=&$tdatabrand;
$field_labels["Brand"] = &$fieldLabelsbrand;
$fieldToolTips["Brand"] = &$fieldToolTipsbrand;
$placeHolders["Brand"] = &$placeHoldersbrand;
$page_titles["Brand"] = &$pageTitlesbrand;


changeTextControlsToDate( "Brand" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["Brand"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["Brand"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//


require_once( getabspath( "include/brand_ops.php" ) );



	
		;

		

$tdatabrand[".sqlquery"] = $queryData_brand;



$tdatabrand[".hasEvents"] = false;

?>