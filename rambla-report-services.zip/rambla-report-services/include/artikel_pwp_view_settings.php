<?php
$tdataartikel_pwp_view = array();
$tdataartikel_pwp_view[".searchableFields"] = array();
$tdataartikel_pwp_view[".ShortName"] = "artikel_pwp_view";
$tdataartikel_pwp_view[".OwnerID"] = "";
$tdataartikel_pwp_view[".OriginalTable"] = "artikel_pwp";


$tdataartikel_pwp_view[".pagesByType"] = my_json_decode( "{\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" );
$tdataartikel_pwp_view[".originalPagesByType"] = $tdataartikel_pwp_view[".pagesByType"];
$tdataartikel_pwp_view[".pages"] = types2pages( my_json_decode( "{\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" ) );
$tdataartikel_pwp_view[".originalPages"] = $tdataartikel_pwp_view[".pages"];
$tdataartikel_pwp_view[".defaultPages"] = my_json_decode( "{\"report\":\"report\",\"rprint\":\"rprint\",\"search\":\"search\"}" );
$tdataartikel_pwp_view[".originalDefaultPages"] = $tdataartikel_pwp_view[".defaultPages"];

//	field labels
$fieldLabelsartikel_pwp_view = array();
$fieldToolTipsartikel_pwp_view = array();
$pageTitlesartikel_pwp_view = array();
$placeHoldersartikel_pwp_view = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsartikel_pwp_view["English"] = array();
	$fieldToolTipsartikel_pwp_view["English"] = array();
	$placeHoldersartikel_pwp_view["English"] = array();
	$pageTitlesartikel_pwp_view["English"] = array();
	$fieldLabelsartikel_pwp_view["English"]["DEPT"] = "Dept";
	$fieldToolTipsartikel_pwp_view["English"]["DEPT"] = "";
	$placeHoldersartikel_pwp_view["English"]["DEPT"] = "";
	$fieldLabelsartikel_pwp_view["English"]["barcode"] = "Barcode";
	$fieldToolTipsartikel_pwp_view["English"]["barcode"] = "";
	$placeHoldersartikel_pwp_view["English"]["barcode"] = "";
	$fieldLabelsartikel_pwp_view["English"]["periode"] = "Periode";
	$fieldToolTipsartikel_pwp_view["English"]["periode"] = "";
	$placeHoldersartikel_pwp_view["English"]["periode"] = "";
	$fieldLabelsartikel_pwp_view["English"]["DIVISION"] = "DIVISION";
	$fieldToolTipsartikel_pwp_view["English"]["DIVISION"] = "";
	$placeHoldersartikel_pwp_view["English"]["DIVISION"] = "";
	$fieldLabelsartikel_pwp_view["English"]["SUB_DIVISION"] = "SUB DIVISION";
	$fieldToolTipsartikel_pwp_view["English"]["SUB_DIVISION"] = "";
	$placeHoldersartikel_pwp_view["English"]["SUB_DIVISION"] = "";
	$fieldLabelsartikel_pwp_view["English"]["SUB_DEPT"] = "SUB DEPT";
	$fieldToolTipsartikel_pwp_view["English"]["SUB_DEPT"] = "";
	$placeHoldersartikel_pwp_view["English"]["SUB_DEPT"] = "";
	$fieldLabelsartikel_pwp_view["English"]["brand_name"] = "Brand Name";
	$fieldToolTipsartikel_pwp_view["English"]["brand_name"] = "";
	$placeHoldersartikel_pwp_view["English"]["brand_name"] = "";
	$fieldLabelsartikel_pwp_view["English"]["article_name"] = "Article Name";
	$fieldToolTipsartikel_pwp_view["English"]["article_name"] = "";
	$placeHoldersartikel_pwp_view["English"]["article_name"] = "";
	$fieldLabelsartikel_pwp_view["English"]["article_number"] = "Article Number";
	$fieldToolTipsartikel_pwp_view["English"]["article_number"] = "";
	$placeHoldersartikel_pwp_view["English"]["article_number"] = "";
	$fieldLabelsartikel_pwp_view["English"]["jual"] = "Jual";
	$fieldToolTipsartikel_pwp_view["English"]["jual"] = "";
	$placeHoldersartikel_pwp_view["English"]["jual"] = "";
	$fieldLabelsartikel_pwp_view["English"]["last_stock"] = "Last Stock";
	$fieldToolTipsartikel_pwp_view["English"]["last_stock"] = "";
	$placeHoldersartikel_pwp_view["English"]["last_stock"] = "";
	if (count($fieldToolTipsartikel_pwp_view["English"]))
		$tdataartikel_pwp_view[".isUseToolTips"] = true;
}


	$tdataartikel_pwp_view[".NCSearch"] = true;



$tdataartikel_pwp_view[".shortTableName"] = "artikel_pwp_view";
$tdataartikel_pwp_view[".nSecOptions"] = 0;

$tdataartikel_pwp_view[".mainTableOwnerID"] = "";
$tdataartikel_pwp_view[".entityType"] = 2;
$tdataartikel_pwp_view[".connId"] = "dbcentral_at_192_168_8_99";


$tdataartikel_pwp_view[".strOriginalTableName"] = "artikel_pwp";

	



$tdataartikel_pwp_view[".showAddInPopup"] = false;

$tdataartikel_pwp_view[".showEditInPopup"] = false;

$tdataartikel_pwp_view[".showViewInPopup"] = false;

$tdataartikel_pwp_view[".listAjax"] = false;
//	temporary
//$tdataartikel_pwp_view[".listAjax"] = false;

	$tdataartikel_pwp_view[".audit"] = false;

	$tdataartikel_pwp_view[".locking"] = false;


$pages = $tdataartikel_pwp_view[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataartikel_pwp_view[".edit"] = true;
	$tdataartikel_pwp_view[".afterEditAction"] = 1;
	$tdataartikel_pwp_view[".closePopupAfterEdit"] = 1;
	$tdataartikel_pwp_view[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataartikel_pwp_view[".add"] = true;
$tdataartikel_pwp_view[".afterAddAction"] = 1;
$tdataartikel_pwp_view[".closePopupAfterAdd"] = 1;
$tdataartikel_pwp_view[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataartikel_pwp_view[".list"] = true;
}



$tdataartikel_pwp_view[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataartikel_pwp_view[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataartikel_pwp_view[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataartikel_pwp_view[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataartikel_pwp_view[".printFriendly"] = true;
}



$tdataartikel_pwp_view[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataartikel_pwp_view[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataartikel_pwp_view[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataartikel_pwp_view[".isUseAjaxSuggest"] = true;





$tdataartikel_pwp_view[".ajaxCodeSnippetAdded"] = false;

$tdataartikel_pwp_view[".buttonsAdded"] = false;

$tdataartikel_pwp_view[".addPageEvents"] = false;

// use timepicker for search panel
$tdataartikel_pwp_view[".isUseTimeForSearch"] = false;


$tdataartikel_pwp_view[".badgeColor"] = "BC8F8F";


$tdataartikel_pwp_view[".allSearchFields"] = array();
$tdataartikel_pwp_view[".filterFields"] = array();
$tdataartikel_pwp_view[".requiredSearchFields"] = array();

$tdataartikel_pwp_view[".googleLikeFields"] = array();
$tdataartikel_pwp_view[".googleLikeFields"][] = "periode";
$tdataartikel_pwp_view[".googleLikeFields"][] = "DIVISION";
$tdataartikel_pwp_view[".googleLikeFields"][] = "SUB_DIVISION";
$tdataartikel_pwp_view[".googleLikeFields"][] = "DEPT";
$tdataartikel_pwp_view[".googleLikeFields"][] = "SUB_DEPT";
$tdataartikel_pwp_view[".googleLikeFields"][] = "brand_name";
$tdataartikel_pwp_view[".googleLikeFields"][] = "article_name";
$tdataartikel_pwp_view[".googleLikeFields"][] = "article_number";
$tdataartikel_pwp_view[".googleLikeFields"][] = "barcode";
$tdataartikel_pwp_view[".googleLikeFields"][] = "jual";
$tdataartikel_pwp_view[".googleLikeFields"][] = "last_stock";



$tdataartikel_pwp_view[".tableType"] = "report";

$tdataartikel_pwp_view[".printerPageOrientation"] = 1;
$tdataartikel_pwp_view[".nPrinterPageScale"] = 100;

$tdataartikel_pwp_view[".nPrinterSplitRecords"] = 40;

$tdataartikel_pwp_view[".geocodingEnabled"] = false;

//report settings

$tdataartikel_pwp_view[".reportPrintGroupsPerPage"] = 3;
$tdataartikel_pwp_view[".reportPrintRecordsPerPage"] = 40;

$tdataartikel_pwp_view[".pageSizeGroups"] = 5;
$tdataartikel_pwp_view[".pageSizeRecords"] = 20;


//end of report settings










$tstrOrderBy = "";
$tdataartikel_pwp_view[".strOrderBy"] = $tstrOrderBy;

$tdataartikel_pwp_view[".orderindexes"] = array();


$tdataartikel_pwp_view[".sqlHead"] = "select date_format(period , '%Y.%m') periode, mkl.DIVISION , mkl.SUB_DIVISION , mkl.DEPT , mkl.SUB_DEPT,  mb.brand_name, mim.article_name, sis.article_number, sis.barcode,  (sales - refund) jual, last_stock";
$tdataartikel_pwp_view[".sqlFrom"] = "from s_item_stok sis   left join m_item_master mim on sis.article_number=mim.article_number   left join m_brand mb on mim.brand = mb.brand_code  left join m_kategori_list mkl on mim.category_code = mkl.category_code";
$tdataartikel_pwp_view[".sqlWhereExpr"] = "period between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'  and mim.category_code != 'RSOTMKVC01' and sales-refund !=0 and last_stock !=0";
$tdataartikel_pwp_view[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataartikel_pwp_view[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataartikel_pwp_view[".arrGroupsPerPage"] = $arrGPP;

$tdataartikel_pwp_view[".highlightSearchResults"] = true;

$tableKeysartikel_pwp_view = array();
$tableKeysartikel_pwp_view[] = "barcode";
$tdataartikel_pwp_view[".Keys"] = $tableKeysartikel_pwp_view;


$tdataartikel_pwp_view[".hideMobileList"] = array();




//	periode
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "periode";
	$fdata["GoodName"] = "periode";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","periode");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "periode";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "date_format(period , '%Y.%m')";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["periode"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "periode";
//	DIVISION
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "DIVISION";
	$fdata["GoodName"] = "DIVISION";
	$fdata["ownerTable"] = "m_kategori_list";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","DIVISION");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DIVISION";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mkl.DIVISION";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["DIVISION"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "DIVISION";
//	SUB_DIVISION
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "SUB_DIVISION";
	$fdata["GoodName"] = "SUB_DIVISION";
	$fdata["ownerTable"] = "m_kategori_list";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","SUB_DIVISION");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "SUB_DIVISION";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mkl.SUB_DIVISION";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["SUB_DIVISION"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "SUB_DIVISION";
//	DEPT
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "DEPT";
	$fdata["GoodName"] = "DEPT";
	$fdata["ownerTable"] = "m_kategori_list";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","DEPT");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DEPT";

		$fdata["sourceSingle"] = "dept";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mkl.DEPT";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=45";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["DEPT"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "DEPT";
//	SUB_DEPT
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "SUB_DEPT";
	$fdata["GoodName"] = "SUB_DEPT";
	$fdata["ownerTable"] = "m_kategori_list";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","SUB_DEPT");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "SUB_DEPT";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mkl.SUB_DEPT";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["SUB_DEPT"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "SUB_DEPT";
//	brand_name
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "brand_name";
	$fdata["GoodName"] = "brand_name";
	$fdata["ownerTable"] = "m_brand";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","brand_name");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_name";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mb.brand_name";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["brand_name"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "brand_name";
//	article_name
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "article_name";
	$fdata["GoodName"] = "article_name";
	$fdata["ownerTable"] = "m_item_master";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","article_name");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "article_name";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mim.article_name";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["article_name"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "article_name";
//	article_number
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "article_number";
	$fdata["GoodName"] = "article_number";
	$fdata["ownerTable"] = "s_item_stok";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","article_number");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "article_number";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "sis.article_number";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["article_number"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "article_number";
//	barcode
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "barcode";
	$fdata["GoodName"] = "barcode";
	$fdata["ownerTable"] = "s_item_stok";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","barcode");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "barcode";

		$fdata["sourceSingle"] = "barcode";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "sis.barcode";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["barcode"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "barcode";
//	jual
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "jual";
	$fdata["GoodName"] = "jual";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","jual");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "jual";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "(sales - refund)";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["jual"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "jual";
//	last_stock
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "last_stock";
	$fdata["GoodName"] = "last_stock";
	$fdata["ownerTable"] = "s_item_stok";
	$fdata["Label"] = GetFieldLabel("artikel_pwp_view","last_stock");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "last_stock";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "last_stock";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataartikel_pwp_view["last_stock"] = $fdata;
		$tdataartikel_pwp_view[".searchableFields"][] = "last_stock";


$tables_data["artikel_pwp_view"]=&$tdataartikel_pwp_view;
$field_labels["artikel_pwp_view"] = &$fieldLabelsartikel_pwp_view;
$fieldToolTips["artikel_pwp_view"] = &$fieldToolTipsartikel_pwp_view;
$placeHolders["artikel_pwp_view"] = &$placeHoldersartikel_pwp_view;
$page_titles["artikel_pwp_view"] = &$pageTitlesartikel_pwp_view;


changeTextControlsToDate( "artikel_pwp_view" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["artikel_pwp_view"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["artikel_pwp_view"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_artikel_pwp_view()
{
$proto0=array();
$proto0["m_strHead"] = "select";
$proto0["m_strFieldList"] = "date_format(period , '%Y.%m') periode, mkl.DIVISION , mkl.SUB_DIVISION , mkl.DEPT , mkl.SUB_DEPT,  mb.brand_name, mim.article_name, sis.article_number, sis.barcode,  (sales - refund) jual, last_stock";
$proto0["m_strFrom"] = "from s_item_stok sis   left join m_item_master mim on sis.article_number=mim.article_number   left join m_brand mb on mim.brand = mb.brand_code  left join m_kategori_list mkl on mim.category_code = mkl.category_code";
$proto0["m_strWhere"] = "period between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'  and mim.category_code != 'RSOTMKVC01' and sales-refund !=0 and last_stock !=0";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "period between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'  and mim.category_code != 'RSOTMKVC01' and sales-refund !=0 and last_stock !=0";
$proto2["m_uniontype"] = "SQLL_AND";
	$obj = new SQLNonParsed(array(
	"m_sql" => "period between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'  and mim.category_code != 'RSOTMKVC01' and sales-refund !=0 and last_stock !=0"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
						$proto4=array();
$proto4["m_sql"] = "period between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "period",
	"m_strTable" => "sis",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "between '2023-04-01 00:00:00' and '2023-06-01 00:00:00'";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

			$proto2["m_contained"][]=$obj;
						$proto6=array();
$proto6["m_sql"] = "mim.category_code != 'RSOTMKVC01'";
$proto6["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "category_code",
	"m_strTable" => "mim",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto6["m_column"]=$obj;
$proto6["m_contained"] = array();
$proto6["m_strCase"] = "!= 'RSOTMKVC01'";
$proto6["m_havingmode"] = false;
$proto6["m_inBrackets"] = false;
$proto6["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto6);

			$proto2["m_contained"][]=$obj;
						$proto8=array();
$proto8["m_sql"] = "sales-refund !=0";
$proto8["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLNonParsed(array(
	"m_sql" => "sales-refund"
));

$proto8["m_column"]=$obj;
$proto8["m_contained"] = array();
$proto8["m_strCase"] = "!=0";
$proto8["m_havingmode"] = false;
$proto8["m_inBrackets"] = false;
$proto8["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto8);

			$proto2["m_contained"][]=$obj;
						$proto10=array();
$proto10["m_sql"] = "last_stock !=0";
$proto10["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "last_stock",
	"m_strTable" => "sis",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto10["m_column"]=$obj;
$proto10["m_contained"] = array();
$proto10["m_strCase"] = "!=0";
$proto10["m_havingmode"] = false;
$proto10["m_inBrackets"] = false;
$proto10["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto10);

			$proto2["m_contained"][]=$obj;
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto12=array();
$proto12["m_sql"] = "";
$proto12["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto12["m_column"]=$obj;
$proto12["m_contained"] = array();
$proto12["m_strCase"] = "";
$proto12["m_havingmode"] = false;
$proto12["m_inBrackets"] = false;
$proto12["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto12);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto14=array();
			$proto15=array();
$proto15["m_functiontype"] = "SQLF_CUSTOM";
$proto15["m_arguments"] = array();
						$obj = new SQLNonParsed(array(
	"m_sql" => "period"
));

$proto15["m_arguments"][]=$obj;
						$obj = new SQLNonParsed(array(
	"m_sql" => "'%Y.%m'"
));

$proto15["m_arguments"][]=$obj;
$proto15["m_strFunctionName"] = "date_format";
$obj = new SQLFunctionCall($proto15);

$proto14["m_sql"] = "date_format(period , '%Y.%m')";
$proto14["m_srcTableName"] = "artikel_pwp_view";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "periode";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "DIVISION",
	"m_strTable" => "mkl",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto18["m_sql"] = "mkl.DIVISION";
$proto18["m_srcTableName"] = "artikel_pwp_view";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "SUB_DIVISION",
	"m_strTable" => "mkl",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto20["m_sql"] = "mkl.SUB_DIVISION";
$proto20["m_srcTableName"] = "artikel_pwp_view";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "DEPT",
	"m_strTable" => "mkl",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto22["m_sql"] = "mkl.DEPT";
$proto22["m_srcTableName"] = "artikel_pwp_view";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
						$proto24=array();
			$obj = new SQLField(array(
	"m_strName" => "SUB_DEPT",
	"m_strTable" => "mkl",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto24["m_sql"] = "mkl.SUB_DEPT";
$proto24["m_srcTableName"] = "artikel_pwp_view";
$proto24["m_expr"]=$obj;
$proto24["m_alias"] = "";
$obj = new SQLFieldListItem($proto24);

$proto0["m_fieldlist"][]=$obj;
						$proto26=array();
			$obj = new SQLField(array(
	"m_strName" => "brand_name",
	"m_strTable" => "mb",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto26["m_sql"] = "mb.brand_name";
$proto26["m_srcTableName"] = "artikel_pwp_view";
$proto26["m_expr"]=$obj;
$proto26["m_alias"] = "";
$obj = new SQLFieldListItem($proto26);

$proto0["m_fieldlist"][]=$obj;
						$proto28=array();
			$obj = new SQLField(array(
	"m_strName" => "article_name",
	"m_strTable" => "mim",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto28["m_sql"] = "mim.article_name";
$proto28["m_srcTableName"] = "artikel_pwp_view";
$proto28["m_expr"]=$obj;
$proto28["m_alias"] = "";
$obj = new SQLFieldListItem($proto28);

$proto0["m_fieldlist"][]=$obj;
						$proto30=array();
			$obj = new SQLField(array(
	"m_strName" => "article_number",
	"m_strTable" => "sis",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto30["m_sql"] = "sis.article_number";
$proto30["m_srcTableName"] = "artikel_pwp_view";
$proto30["m_expr"]=$obj;
$proto30["m_alias"] = "";
$obj = new SQLFieldListItem($proto30);

$proto0["m_fieldlist"][]=$obj;
						$proto32=array();
			$obj = new SQLField(array(
	"m_strName" => "barcode",
	"m_strTable" => "sis",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto32["m_sql"] = "sis.barcode";
$proto32["m_srcTableName"] = "artikel_pwp_view";
$proto32["m_expr"]=$obj;
$proto32["m_alias"] = "";
$obj = new SQLFieldListItem($proto32);

$proto0["m_fieldlist"][]=$obj;
						$proto34=array();
			$obj = new SQLNonParsed(array(
	"m_sql" => "(sales - refund)"
));

$proto34["m_sql"] = "(sales - refund)";
$proto34["m_srcTableName"] = "artikel_pwp_view";
$proto34["m_expr"]=$obj;
$proto34["m_alias"] = "jual";
$obj = new SQLFieldListItem($proto34);

$proto0["m_fieldlist"][]=$obj;
						$proto36=array();
			$obj = new SQLField(array(
	"m_strName" => "last_stock",
	"m_strTable" => "sis",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto36["m_sql"] = "last_stock";
$proto36["m_srcTableName"] = "artikel_pwp_view";
$proto36["m_expr"]=$obj;
$proto36["m_alias"] = "";
$obj = new SQLFieldListItem($proto36);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto38=array();
$proto38["m_link"] = "SQLL_MAIN";
			$proto39=array();
$proto39["m_strName"] = "s_item_stok";
$proto39["m_srcTableName"] = "artikel_pwp_view";
$proto39["m_columns"] = array();
$proto39["m_columns"][] = "period";
$proto39["m_columns"][] = "article_code";
$proto39["m_columns"][] = "article_number";
$proto39["m_columns"][] = "barcode";
$proto39["m_columns"][] = "sku_code";
$proto39["m_columns"][] = "supplier_pcode";
$proto39["m_columns"][] = "first_stock";
$proto39["m_columns"][] = "receipt";
$proto39["m_columns"][] = "issue";
$proto39["m_columns"][] = "sales";
$proto39["m_columns"][] = "refund";
$proto39["m_columns"][] = "adj_in";
$proto39["m_columns"][] = "adj_out";
$proto39["m_columns"][] = "transfer_in";
$proto39["m_columns"][] = "transfer_out";
$proto39["m_columns"][] = "last_stock";
$proto39["m_columns"][] = "on_hold";
$proto39["m_columns"][] = "transit";
$obj = new SQLTable($proto39);

$proto38["m_table"] = $obj;
$proto38["m_sql"] = "s_item_stok sis";
$proto38["m_alias"] = "sis";
$proto38["m_srcTableName"] = "artikel_pwp_view";
$proto40=array();
$proto40["m_sql"] = "";
$proto40["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto40["m_column"]=$obj;
$proto40["m_contained"] = array();
$proto40["m_strCase"] = "";
$proto40["m_havingmode"] = false;
$proto40["m_inBrackets"] = false;
$proto40["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto40);

$proto38["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto38);

$proto0["m_fromlist"][]=$obj;
												$proto42=array();
$proto42["m_link"] = "SQLL_LEFTJOIN";
			$proto43=array();
$proto43["m_strName"] = "m_item_master";
$proto43["m_srcTableName"] = "artikel_pwp_view";
$proto43["m_columns"] = array();
$proto43["m_columns"][] = "branch_id";
$proto43["m_columns"][] = "article_code";
$proto43["m_columns"][] = "article_name";
$proto43["m_columns"][] = "supplier_pcode";
$proto43["m_columns"][] = "supplier_pname";
$proto43["m_columns"][] = "description";
$proto43["m_columns"][] = "brand";
$proto43["m_columns"][] = "category_code";
$proto43["m_columns"][] = "integration_code";
$proto43["m_columns"][] = "option1";
$proto43["m_columns"][] = "varian_option1";
$proto43["m_columns"][] = "option2";
$proto43["m_columns"][] = "varian_option2";
$proto43["m_columns"][] = "option3";
$proto43["m_columns"][] = "varian_option3";
$proto43["m_columns"][] = "normal_price";
$proto43["m_columns"][] = "current_price";
$proto43["m_columns"][] = "weight";
$proto43["m_columns"][] = "length";
$proto43["m_columns"][] = "width";
$proto43["m_columns"][] = "height";
$proto43["m_columns"][] = "hex_code";
$proto43["m_columns"][] = "article_gold_type";
$proto43["m_columns"][] = "images";
$proto43["m_columns"][] = "article_number";
$proto43["m_columns"][] = "vendor_code";
$proto43["m_columns"][] = "pos_pname";
$proto43["m_columns"][] = "class";
$proto43["m_columns"][] = "isactive";
$proto43["m_columns"][] = "publish";
$proto43["m_columns"][] = "max_buy";
$proto43["m_columns"][] = "open_price";
$proto43["m_columns"][] = "approved_1";
$proto43["m_columns"][] = "approved_2";
$proto43["m_columns"][] = "approved_3";
$proto43["m_columns"][] = "last_update";
$proto43["m_columns"][] = "notes";
$proto43["m_columns"][] = "tag_1";
$proto43["m_columns"][] = "tag_2";
$proto43["m_columns"][] = "tag_3";
$proto43["m_columns"][] = "tag_4";
$proto43["m_columns"][] = "tag_5";
$proto43["m_columns"][] = "margin_code_0";
$proto43["m_columns"][] = "margin_level_0";
$proto43["m_columns"][] = "margin_code_1";
$proto43["m_columns"][] = "margin_level_1";
$proto43["m_columns"][] = "margin_code_2";
$proto43["m_columns"][] = "margin_level_2";
$proto43["m_columns"][] = "margin_code_3";
$proto43["m_columns"][] = "margin_level_3";
$proto43["m_columns"][] = "margin_code_4";
$proto43["m_columns"][] = "margin_level_4";
$proto43["m_columns"][] = "flag_flexi";
$proto43["m_columns"][] = "flexible0";
$proto43["m_columns"][] = "flexible1";
$proto43["m_columns"][] = "flexible2";
$proto43["m_columns"][] = "flag_tier";
$proto43["m_columns"][] = "price0";
$proto43["m_columns"][] = "qty_price0";
$proto43["m_columns"][] = "price1";
$proto43["m_columns"][] = "qty_price1";
$proto43["m_columns"][] = "price2";
$proto43["m_columns"][] = "qty_price2";
$proto43["m_columns"][] = "flag_1";
$proto43["m_columns"][] = "flag_2";
$proto43["m_columns"][] = "flag_3";
$proto43["m_columns"][] = "sku_code";
$proto43["m_columns"][] = "update_by";
$proto43["m_columns"][] = "add_by";
$proto43["m_columns"][] = "add_date";
$proto43["m_columns"][] = "edit_by";
$proto43["m_columns"][] = "edit_date";
$proto43["m_columns"][] = "flag_gold";
$obj = new SQLTable($proto43);

$proto42["m_table"] = $obj;
$proto42["m_sql"] = "left join m_item_master mim on sis.article_number=mim.article_number";
$proto42["m_alias"] = "mim";
$proto42["m_srcTableName"] = "artikel_pwp_view";
$proto44=array();
$proto44["m_sql"] = "mim.article_number = sis.article_number";
$proto44["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "article_number",
	"m_strTable" => "mim",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto44["m_column"]=$obj;
$proto44["m_contained"] = array();
$proto44["m_strCase"] = "= sis.article_number";
$proto44["m_havingmode"] = false;
$proto44["m_inBrackets"] = false;
$proto44["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto44);

$proto42["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto42);

$proto0["m_fromlist"][]=$obj;
												$proto46=array();
$proto46["m_link"] = "SQLL_LEFTJOIN";
			$proto47=array();
$proto47["m_strName"] = "m_brand";
$proto47["m_srcTableName"] = "artikel_pwp_view";
$proto47["m_columns"] = array();
$proto47["m_columns"][] = "brand_code";
$proto47["m_columns"][] = "brand_name";
$proto47["m_columns"][] = "brand_group";
$proto47["m_columns"][] = "sm";
$obj = new SQLTable($proto47);

$proto46["m_table"] = $obj;
$proto46["m_sql"] = "left join m_brand mb on mim.brand = mb.brand_code";
$proto46["m_alias"] = "mb";
$proto46["m_srcTableName"] = "artikel_pwp_view";
$proto48=array();
$proto48["m_sql"] = "mb.brand_code = mim.brand";
$proto48["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "mb",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto48["m_column"]=$obj;
$proto48["m_contained"] = array();
$proto48["m_strCase"] = "= mim.brand";
$proto48["m_havingmode"] = false;
$proto48["m_inBrackets"] = false;
$proto48["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto48);

$proto46["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto46);

$proto0["m_fromlist"][]=$obj;
												$proto50=array();
$proto50["m_link"] = "SQLL_LEFTJOIN";
			$proto51=array();
$proto51["m_strName"] = "m_kategori_list";
$proto51["m_srcTableName"] = "artikel_pwp_view";
$proto51["m_columns"] = array();
$proto51["m_columns"][] = "seq";
$proto51["m_columns"][] = "KODE_DIVISION";
$proto51["m_columns"][] = "DIVISION";
$proto51["m_columns"][] = "KODE_SUB_DIVISION";
$proto51["m_columns"][] = "SUB_DIVISION";
$proto51["m_columns"][] = "KODE_DEPT";
$proto51["m_columns"][] = "DEPT";
$proto51["m_columns"][] = "KODE_SUB_DEPT";
$proto51["m_columns"][] = "SUB_DEPT";
$proto51["m_columns"][] = "KODE_CATEGORY";
$proto51["m_columns"][] = "CATEGORY";
$proto51["m_columns"][] = "CATEGORY_CODE";
$obj = new SQLTable($proto51);

$proto50["m_table"] = $obj;
$proto50["m_sql"] = "left join m_kategori_list mkl on mim.category_code = mkl.category_code";
$proto50["m_alias"] = "mkl";
$proto50["m_srcTableName"] = "artikel_pwp_view";
$proto52=array();
$proto52["m_sql"] = "mkl.CATEGORY_CODE = mim.category_code";
$proto52["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "CATEGORY_CODE",
	"m_strTable" => "mkl",
	"m_srcTableName" => "artikel_pwp_view"
));

$proto52["m_column"]=$obj;
$proto52["m_contained"] = array();
$proto52["m_strCase"] = "= mim.category_code";
$proto52["m_havingmode"] = false;
$proto52["m_inBrackets"] = false;
$proto52["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto52);

$proto50["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto50);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="artikel_pwp_view";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_artikel_pwp_view = createSqlQuery_artikel_pwp_view();


	
		;

											

$tdataartikel_pwp_view[".sqlquery"] = $queryData_artikel_pwp_view;



$tdataartikel_pwp_view[".hasEvents"] = false;

?>