<?php
$tdatac_sales_brand = array();
$tdatac_sales_brand[".searchableFields"] = array();
$tdatac_sales_brand[".ShortName"] = "c_sales_brand";
$tdatac_sales_brand[".OwnerID"] = "";
$tdatac_sales_brand[".OriginalTable"] = "artikel_pwp";


$tdatac_sales_brand[".pagesByType"] = my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" );
$tdatac_sales_brand[".originalPagesByType"] = $tdatac_sales_brand[".pagesByType"];
$tdatac_sales_brand[".pages"] = types2pages( my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" ) );
$tdatac_sales_brand[".originalPages"] = $tdatac_sales_brand[".pages"];
$tdatac_sales_brand[".defaultPages"] = my_json_decode( "{\"chart\":\"chart\",\"search\":\"search\"}" );
$tdatac_sales_brand[".originalDefaultPages"] = $tdatac_sales_brand[".defaultPages"];

//	field labels
$fieldLabelsc_sales_brand = array();
$fieldToolTipsc_sales_brand = array();
$pageTitlesc_sales_brand = array();
$placeHoldersc_sales_brand = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsc_sales_brand["English"] = array();
	$fieldToolTipsc_sales_brand["English"] = array();
	$placeHoldersc_sales_brand["English"] = array();
	$pageTitlesc_sales_brand["English"] = array();
	$fieldLabelsc_sales_brand["English"]["periode"] = "Periode";
	$fieldToolTipsc_sales_brand["English"]["periode"] = "";
	$placeHoldersc_sales_brand["English"]["periode"] = "";
	$fieldLabelsc_sales_brand["English"]["brand_name"] = "Brand Name";
	$fieldToolTipsc_sales_brand["English"]["brand_name"] = "";
	$placeHoldersc_sales_brand["English"]["brand_name"] = "";
	$fieldLabelsc_sales_brand["English"]["tot_qty"] = "Tot Qty";
	$fieldToolTipsc_sales_brand["English"]["tot_qty"] = "";
	$placeHoldersc_sales_brand["English"]["tot_qty"] = "";
	$fieldLabelsc_sales_brand["English"]["net"] = "Net";
	$fieldToolTipsc_sales_brand["English"]["net"] = "";
	$placeHoldersc_sales_brand["English"]["net"] = "";
	if (count($fieldToolTipsc_sales_brand["English"]))
		$tdatac_sales_brand[".isUseToolTips"] = true;
}


	$tdatac_sales_brand[".NCSearch"] = true;

	$tdatac_sales_brand[".ChartRefreshTime"] = 0;


$tdatac_sales_brand[".shortTableName"] = "c_sales_brand";
$tdatac_sales_brand[".nSecOptions"] = 0;

$tdatac_sales_brand[".mainTableOwnerID"] = "";
$tdatac_sales_brand[".entityType"] = 3;
$tdatac_sales_brand[".connId"] = "dbcentral_at_192_168_8_99";


$tdatac_sales_brand[".strOriginalTableName"] = "artikel_pwp";

	



$tdatac_sales_brand[".showAddInPopup"] = false;

$tdatac_sales_brand[".showEditInPopup"] = false;

$tdatac_sales_brand[".showViewInPopup"] = false;

$tdatac_sales_brand[".listAjax"] = false;
//	temporary
//$tdatac_sales_brand[".listAjax"] = false;

	$tdatac_sales_brand[".audit"] = false;

	$tdatac_sales_brand[".locking"] = false;


$pages = $tdatac_sales_brand[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatac_sales_brand[".edit"] = true;
	$tdatac_sales_brand[".afterEditAction"] = 1;
	$tdatac_sales_brand[".closePopupAfterEdit"] = 1;
	$tdatac_sales_brand[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatac_sales_brand[".add"] = true;
$tdatac_sales_brand[".afterAddAction"] = 1;
$tdatac_sales_brand[".closePopupAfterAdd"] = 1;
$tdatac_sales_brand[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatac_sales_brand[".list"] = true;
}



$tdatac_sales_brand[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatac_sales_brand[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatac_sales_brand[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatac_sales_brand[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatac_sales_brand[".printFriendly"] = true;
}



$tdatac_sales_brand[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatac_sales_brand[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatac_sales_brand[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatac_sales_brand[".isUseAjaxSuggest"] = true;





$tdatac_sales_brand[".ajaxCodeSnippetAdded"] = false;

$tdatac_sales_brand[".buttonsAdded"] = false;

$tdatac_sales_brand[".addPageEvents"] = false;

// use timepicker for search panel
$tdatac_sales_brand[".isUseTimeForSearch"] = false;


$tdatac_sales_brand[".badgeColor"] = "4169E1";


$tdatac_sales_brand[".allSearchFields"] = array();
$tdatac_sales_brand[".filterFields"] = array();
$tdatac_sales_brand[".requiredSearchFields"] = array();

$tdatac_sales_brand[".googleLikeFields"] = array();
$tdatac_sales_brand[".googleLikeFields"][] = "periode";
$tdatac_sales_brand[".googleLikeFields"][] = "brand_name";
$tdatac_sales_brand[".googleLikeFields"][] = "tot_qty";
$tdatac_sales_brand[".googleLikeFields"][] = "net";



$tdatac_sales_brand[".tableType"] = "chart";

$tdatac_sales_brand[".printerPageOrientation"] = 0;
$tdatac_sales_brand[".nPrinterPageScale"] = 100;

$tdatac_sales_brand[".nPrinterSplitRecords"] = 40;

$tdatac_sales_brand[".geocodingEnabled"] = false;



// chart settings
$tdatac_sales_brand[".chartType"] = "2DColumn";
// end of chart settings








$tstrOrderBy = "";
$tdatac_sales_brand[".strOrderBy"] = $tstrOrderBy;

$tdatac_sales_brand[".orderindexes"] = array();


$tdatac_sales_brand[".sqlHead"] = "select date_format(periode, '%Y.%m') AS periode,  brand_name,  SUM(tot_qty) AS tot_qty,  SUM(net) AS net";
$tdatac_sales_brand[".sqlFrom"] = "FROM r_sales";
$tdatac_sales_brand[".sqlWhereExpr"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  ))";
$tdatac_sales_brand[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatac_sales_brand[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatac_sales_brand[".arrGroupsPerPage"] = $arrGPP;

$tdatac_sales_brand[".highlightSearchResults"] = true;

$tableKeysc_sales_brand = array();
$tdatac_sales_brand[".Keys"] = $tableKeysc_sales_brand;


$tdatac_sales_brand[".hideMobileList"] = array();




//	periode
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "periode";
	$fdata["GoodName"] = "periode";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("c_sales_brand","periode");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "periode";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "date_format(periode, '%Y.%m')";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales_brand["periode"] = $fdata;
		$tdatac_sales_brand[".searchableFields"][] = "periode";
//	brand_name
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "brand_name";
	$fdata["GoodName"] = "brand_name";
	$fdata["ownerTable"] = "r_sales";
	$fdata["Label"] = GetFieldLabel("c_sales_brand","brand_name");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "brand_name";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "brand_name";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales_brand["brand_name"] = $fdata;
		$tdatac_sales_brand[".searchableFields"][] = "brand_name";
//	tot_qty
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "tot_qty";
	$fdata["GoodName"] = "tot_qty";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("c_sales_brand","tot_qty");
	$fdata["FieldType"] = 14;


	
	
			

		$fdata["strField"] = "tot_qty";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "SUM(tot_qty)";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales_brand["tot_qty"] = $fdata;
		$tdatac_sales_brand[".searchableFields"][] = "tot_qty";
//	net
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "net";
	$fdata["GoodName"] = "net";
	$fdata["ownerTable"] = "";
	$fdata["Label"] = GetFieldLabel("c_sales_brand","net");
	$fdata["FieldType"] = 5;


	
	
			

		$fdata["strField"] = "net";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "SUM(net)";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatac_sales_brand["net"] = $fdata;
		$tdatac_sales_brand[".searchableFields"][] = "net";

$tdatac_sales_brand[".groupChart"] = true;
$tdatac_sales_brand[".chartLabelInterval"] = 5;
$tdatac_sales_brand[".chartLabelField"] = "brand_name";
$tdatac_sales_brand[".chartSeries"] = array();
$tdatac_sales_brand[".chartSeries"][] = array(
	"field" => "net",
	"total" => "SUM"
);
$tdatac_sales_brand[".chartSeries"][] = array(
	"field" => "tot_qty",
	"total" => "SUM"
);
	$tdatac_sales_brand[".chartXml"] = '<chart>
		<attr value="tables">
			<attr value="0">c_sales_brand</attr>
		</attr>
		<attr value="chart_type">
			<attr value="type">2d_column</attr>
		</attr>

		<attr value="parameters">';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="0">
			<attr value="name">net</attr>';
	$tdatac_sales_brand[".chartXml"] .= '</attr>';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="1">
			<attr value="name">tot_qty</attr>';
	$tdatac_sales_brand[".chartXml"] .= '</attr>';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="2">
		<attr value="name">brand_name</attr>
	</attr>';
	$tdatac_sales_brand[".chartXml"] .= '</attr>
			<attr value="appearance">';


	$tdatac_sales_brand[".chartXml"] .= '<attr value="head">'.xmlencode("artikel_pwp_view").'</attr>
<attr value="foot">'.xmlencode("Legend Title").'</attr>
<attr value="y_axis_label">'.xmlencode("qty_total").'</attr>


<attr value="slegend">true</attr>
<attr value="sgrid">true</attr>
<attr value="sname">true</attr>
<attr value="sval">true</attr>
<attr value="sanim">true</attr>
<attr value="sstacked">false</attr>
<attr value="slog">false</attr>
<attr value="aqua">0</attr>
<attr value="cview">0</attr>
<attr value="is3d">0</attr>
<attr value="isstacked">0</attr>
<attr value="linestyle">0</attr>
<attr value="autoupdate">0</attr>
<attr value="autoupmin">60</attr>';
$tdatac_sales_brand[".chartXml"] .= '</attr>

<attr value="fields">';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="0">
		<attr value="name">periode</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales_brand","periode")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="1">
		<attr value="name">brand_name</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales_brand","brand_name")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="2">
		<attr value="name">tot_qty</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales_brand","tot_qty")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatac_sales_brand[".chartXml"] .= '<attr value="3">
		<attr value="name">net</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("c_sales_brand","net")).'</attr>
		<attr value="search"></attr>
	</attr>';
$tdatac_sales_brand[".chartXml"] .= '</attr>


<attr value="settings">
<attr value="name">c_sales_brand</attr>
<attr value="short_table_name">c_sales_brand</attr>
</attr>

</chart>';

$tables_data["c_sales_brand"]=&$tdatac_sales_brand;
$field_labels["c_sales_brand"] = &$fieldLabelsc_sales_brand;
$fieldToolTips["c_sales_brand"] = &$fieldToolTipsc_sales_brand;
$placeHolders["c_sales_brand"] = &$placeHoldersc_sales_brand;
$page_titles["c_sales_brand"] = &$pageTitlesc_sales_brand;


changeTextControlsToDate( "c_sales_brand" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["c_sales_brand"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["c_sales_brand"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_c_sales_brand()
{
$proto0=array();
$proto0["m_strHead"] = "select";
$proto0["m_strFieldList"] = "date_format(periode, '%Y.%m') AS periode,  brand_name,  SUM(tot_qty) AS tot_qty,  SUM(net) AS net";
$proto0["m_strFrom"] = "FROM r_sales";
$proto0["m_strWhere"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  ))";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  ))";
$proto2["m_uniontype"] = "SQLL_AND";
	$obj = new SQLNonParsed(array(
	"m_sql" => "(date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')) AND (brand_code in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  ))"
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
						$proto4=array();
$proto4["m_sql"] = "date_format(periode, '%Y.%m.%d') between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
						$proto5=array();
$proto5["m_functiontype"] = "SQLF_CUSTOM";
$proto5["m_arguments"] = array();
						$obj = new SQLNonParsed(array(
	"m_sql" => "periode"
));

$proto5["m_arguments"][]=$obj;
						$obj = new SQLNonParsed(array(
	"m_sql" => "'%Y.%m.%d'"
));

$proto5["m_arguments"][]=$obj;
$proto5["m_strFunctionName"] = "date_format";
$obj = new SQLFunctionCall($proto5);

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "between '2023.03.01' and date_format(current_date(),'%Y.%m.%d')";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = true;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

			$proto2["m_contained"][]=$obj;
						$proto8=array();
$proto8["m_sql"] = "brand_code in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  )";
$proto8["m_uniontype"] = "SQLL_UNKNOWN";
						$obj = new SQLField(array(
	"m_strName" => "brand_code",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales_brand"
));

$proto8["m_column"]=$obj;
$proto8["m_contained"] = array();
$proto8["m_strCase"] = "in (  	select distinct brand from v_user_login_brand   	where username = ':user.username'  )";
$proto8["m_havingmode"] = false;
$proto8["m_inBrackets"] = true;
$proto8["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto8);

			$proto2["m_contained"][]=$obj;
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto10=array();
$proto10["m_sql"] = "";
$proto10["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto10["m_column"]=$obj;
$proto10["m_contained"] = array();
$proto10["m_strCase"] = "";
$proto10["m_havingmode"] = false;
$proto10["m_inBrackets"] = false;
$proto10["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto10);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto12=array();
			$proto13=array();
$proto13["m_functiontype"] = "SQLF_CUSTOM";
$proto13["m_arguments"] = array();
						$obj = new SQLNonParsed(array(
	"m_sql" => "periode"
));

$proto13["m_arguments"][]=$obj;
						$obj = new SQLNonParsed(array(
	"m_sql" => "'%Y.%m'"
));

$proto13["m_arguments"][]=$obj;
$proto13["m_strFunctionName"] = "date_format";
$obj = new SQLFunctionCall($proto13);

$proto12["m_sql"] = "date_format(periode, '%Y.%m')";
$proto12["m_srcTableName"] = "c_sales_brand";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "periode";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "brand_name",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales_brand"
));

$proto16["m_sql"] = "brand_name";
$proto16["m_srcTableName"] = "c_sales_brand";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$proto19=array();
$proto19["m_functiontype"] = "SQLF_SUM";
$proto19["m_arguments"] = array();
						$obj = new SQLField(array(
	"m_strName" => "tot_qty",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales_brand"
));

$proto19["m_arguments"][]=$obj;
$proto19["m_strFunctionName"] = "SUM";
$obj = new SQLFunctionCall($proto19);

$proto18["m_sql"] = "SUM(tot_qty)";
$proto18["m_srcTableName"] = "c_sales_brand";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "tot_qty";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto21=array();
			$proto22=array();
$proto22["m_functiontype"] = "SQLF_SUM";
$proto22["m_arguments"] = array();
						$obj = new SQLField(array(
	"m_strName" => "net",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales_brand"
));

$proto22["m_arguments"][]=$obj;
$proto22["m_strFunctionName"] = "SUM";
$obj = new SQLFunctionCall($proto22);

$proto21["m_sql"] = "SUM(net)";
$proto21["m_srcTableName"] = "c_sales_brand";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "net";
$obj = new SQLFieldListItem($proto21);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto24=array();
$proto24["m_link"] = "SQLL_MAIN";
			$proto25=array();
$proto25["m_strName"] = "r_sales";
$proto25["m_srcTableName"] = "c_sales_brand";
$proto25["m_columns"] = array();
$proto25["m_columns"][] = "id";
$proto25["m_columns"][] = "periode";
$proto25["m_columns"][] = "DIVISION";
$proto25["m_columns"][] = "SUB_DIVISION";
$proto25["m_columns"][] = "category_code";
$proto25["m_columns"][] = "DEPT";
$proto25["m_columns"][] = "SUB_DEPT";
$proto25["m_columns"][] = "brand_code";
$proto25["m_columns"][] = "brand_name";
$proto25["m_columns"][] = "barcode";
$proto25["m_columns"][] = "article_name";
$proto25["m_columns"][] = "varian_option1";
$proto25["m_columns"][] = "varian_option2";
$proto25["m_columns"][] = "price";
$proto25["m_columns"][] = "vendor_code";
$proto25["m_columns"][] = "margin";
$proto25["m_columns"][] = "tot_qty";
$proto25["m_columns"][] = "disc_pct";
$proto25["m_columns"][] = "total_disc_amt";
$proto25["m_columns"][] = "moredisc_pct";
$proto25["m_columns"][] = "total_moredisc_amt";
$proto25["m_columns"][] = "gross";
$proto25["m_columns"][] = "net";
$proto25["m_columns"][] = "gross_after_margin";
$proto25["m_columns"][] = "source_dat";
$proto25["m_columns"][] = "tag_5";
$proto25["m_columns"][] = "vendor_type";
$proto25["m_columns"][] = "fee";
$obj = new SQLTable($proto25);

$proto24["m_table"] = $obj;
$proto24["m_sql"] = "r_sales";
$proto24["m_alias"] = "";
$proto24["m_srcTableName"] = "c_sales_brand";
$proto26=array();
$proto26["m_sql"] = "";
$proto26["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto26["m_column"]=$obj;
$proto26["m_contained"] = array();
$proto26["m_strCase"] = "";
$proto26["m_havingmode"] = false;
$proto26["m_inBrackets"] = false;
$proto26["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto26);

$proto24["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto24);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
												$proto28=array();
						$proto29=array();
$proto29["m_functiontype"] = "SQLF_CUSTOM";
$proto29["m_arguments"] = array();
						$obj = new SQLNonParsed(array(
	"m_sql" => "periode"
));

$proto29["m_arguments"][]=$obj;
						$obj = new SQLNonParsed(array(
	"m_sql" => "'%Y.%m'"
));

$proto29["m_arguments"][]=$obj;
$proto29["m_strFunctionName"] = "date_format";
$obj = new SQLFunctionCall($proto29);

$proto28["m_column"]=$obj;
$obj = new SQLGroupByItem($proto28);

$proto0["m_groupby"][]=$obj;
												$proto32=array();
						$obj = new SQLField(array(
	"m_strName" => "brand_name",
	"m_strTable" => "r_sales",
	"m_srcTableName" => "c_sales_brand"
));

$proto32["m_column"]=$obj;
$obj = new SQLGroupByItem($proto32);

$proto0["m_groupby"][]=$obj;
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="c_sales_brand";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_c_sales_brand = createSqlQuery_c_sales_brand();


	
		;

				

$tdatac_sales_brand[".sqlquery"] = $queryData_c_sales_brand;



$tdatac_sales_brand[".hasEvents"] = false;

?>