<?php
$topsarticle_report = array();
		$topsarticle_report["selectList"] = array(
		"subtype" => "sql",
		"sql" => "SELECT * FROM  r_item_master where brand in ( select brand from v_user_login_brand where username = ':user.username')
"
	);
		$tables_data["Article_Report"][".operations"] = &$topsarticle_report;
?>