<?php
class eventsBase
{
	var $events = array();
	var $maps = array();
	function exists($event, $table = "")
	{
		if($table == "")
			return (array_key_exists($event,$this->events)!==FALSE);
		else
			return isset($this->events[$event]) && isset($this->events[$event][$table]);
	}

	function existsMap($page)
	{
		return (array_key_exists($page,$this->maps)!==FALSE);
	}
}

class class_GlobalEvents extends eventsBase
{
	function __construct()
	{
	// fill list of events
		$this->events["AfterSuccessfulLogin"]=true;

		$this->events["BeforeLogin"]=true;


//	onscreen events
		$this->events["Onprogress_bar_table2_snippet"] = true;



		}

//	handlers

		
		
		
		
		
		
				// After successful login
function AfterSuccessfulLogin($username, $password, &$data, $pageObject)
{

		

//**********  Redirect to another page  ************
header("Location: view_dashboard.php?page=dashboard");
exit();



// Place event code here.
// Use "Add Action" button to add code snippets.
;
} // function AfterSuccessfulLogin

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		
		
		
		
		
				// Before login
function BeforeLogin(&$username, &$password, &$message, $pageObject, &$values)
{

		

// Place event code here.
// Use "Add Action" button to add code snippets.

return true;

$html = <<<EOT
<script src="bootstrap-waitingfor/bootstrap-waitingfor.js"></script>
<script>

$.ajax({
	  type: "POST", //we are using POST method to submit the data to the server side
	  url: './ajax_control.php', // get the route value
	  beforeSend: function () {//We add this before send to disable the button once we submit it so that we prevent the multiple click
			waitingDialog.show('60 seg. ---- Loading Something...',{
			  // if the option is set to boolean false, it will hide the header and "message" will be set in a paragraph above the progress bar.
			  // When headerText is a not-empty string, "message" becomes a content above the progress bar and headerText string will be set as a text inside the H3;
			  headerText: 'Prepare data to report services',
			  // this will generate a heading corresponding to the size number
			  headerSize: 3,
			  // extra class(es) for the header tag
			  headerClass: '',
			  // bootstrap postfix for dialog size, e.g. "sm", "m"
			  dialogSize: 'm',
			  // bootstrap postfix for progress bar type, e.g. "success", "warning";
			  progressType: '',
			  // determines the tag of the content element
			  contentElement: 'p',
			  // extra class(es) for the content tag
			  contentClass: 'content'
			});
	  },
	  success: function (response) {//once the request successfully process to the server side it will return result here
			// waitingDialog.hide(); 
	  },
	  complete: function() {
			waitingDialog.hide();
	  },
	  error: function (XMLHttpRequest, textStatus, errorThrown) {
		// You can put something here if there is an error from submitted request
	  }
 });


</script>

EOT;

echo $html;
;
} // function BeforeLogin

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

//	onscreen events
	function event_Onprogress_bar_table2_snippet(&$params)
	{
	
	;
}




}
?>