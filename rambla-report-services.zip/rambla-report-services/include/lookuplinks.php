<?php

/**
* getLookupMainTableSettings - tests whether the lookup link exists between the tables
*
*  returns array with ProjectSettings class for main table if the link exists in project settings.
*  returns NULL otherwise
*/
function getLookupMainTableSettings($lookupTable, $mainTableShortName, $mainField, $desiredPage = "")
{
	global $lookupTableLinks;
	if(!isset($lookupTableLinks[$lookupTable]))
		return null;
	if(!isset($lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField]))
		return null;
	$arr = &$lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField];
	$effectivePage = $desiredPage;
	if(!isset($arr[$effectivePage]))
	{
		$effectivePage = PAGE_EDIT;
		if(!isset($arr[$effectivePage]))
		{
			if($desiredPage == "" && 0 < count($arr))
			{
				$effectivePage = $arr[0];
			}
			else
				return null;
		}
	}
	return new ProjectSettings($arr[$effectivePage]["table"], $effectivePage);
}

/** 
* $lookupTableLinks array stores all lookup links between tables in the project
*/
function InitLookupLinks()
{
	global $lookupTableLinks;

	$lookupTableLinks = array();

		if( !isset( $lookupTableLinks["Brand"] ) ) {
			$lookupTableLinks["Brand"] = array();
		}
		if( !isset( $lookupTableLinks["Brand"]["promo_report.brand"] )) {
			$lookupTableLinks["Brand"]["promo_report.brand"] = array();
		}
		$lookupTableLinks["Brand"]["promo_report.brand"]["edit"] = array("table" => "Promo_Report", "field" => "brand", "page" => "edit");
		if( !isset( $lookupTableLinks["t_promo_type"] ) ) {
			$lookupTableLinks["t_promo_type"] = array();
		}
		if( !isset( $lookupTableLinks["t_promo_type"]["promo_report.promo_type"] )) {
			$lookupTableLinks["t_promo_type"]["promo_report.promo_type"] = array();
		}
		$lookupTableLinks["t_promo_type"]["promo_report.promo_type"]["edit"] = array("table" => "Promo_Report", "field" => "promo_type", "page" => "edit");
		if( !isset( $lookupTableLinks["department_brand4"] ) ) {
			$lookupTableLinks["department_brand4"] = array();
		}
		if( !isset( $lookupTableLinks["department_brand4"]["sales_report.DEPT"] )) {
			$lookupTableLinks["department_brand4"]["sales_report.DEPT"] = array();
		}
		$lookupTableLinks["department_brand4"]["sales_report.DEPT"]["edit"] = array("table" => "Sales_Report", "field" => "DEPT", "page" => "edit");
		if( !isset( $lookupTableLinks["v_user_login_brand2"] ) ) {
			$lookupTableLinks["v_user_login_brand2"] = array();
		}
		if( !isset( $lookupTableLinks["v_user_login_brand2"]["sales_report.brand_name"] )) {
			$lookupTableLinks["v_user_login_brand2"]["sales_report.brand_name"] = array();
		}
		$lookupTableLinks["v_user_login_brand2"]["sales_report.brand_name"]["edit"] = array("table" => "Sales_Report", "field" => "brand_name", "page" => "edit");
		if( !isset( $lookupTableLinks["v_user_login_brand2"] ) ) {
			$lookupTableLinks["v_user_login_brand2"] = array();
		}
		if( !isset( $lookupTableLinks["v_user_login_brand2"]["sales_report.brand_code"] )) {
			$lookupTableLinks["v_user_login_brand2"]["sales_report.brand_code"] = array();
		}
		$lookupTableLinks["v_user_login_brand2"]["sales_report.brand_code"]["edit"] = array("table" => "Sales_Report", "field" => "brand_code", "page" => "edit");
}

?>