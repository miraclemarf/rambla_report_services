<?php

function getMenuNodes_secondary($menuNodesObject)
{
	// create menu nodes arr
	$menuNodesObject->menuNodes["secondary"] = array();

}
?>